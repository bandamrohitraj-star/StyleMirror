#!/usr/bin/env python3
"""
STYLE MIRROR Backend API Test Suite
Tests all backend routes under /api via app/api/[[...path]]/route.js
"""
import requests
import json
import time
import os
from io import BytesIO

# Load base URL from .env
BASE_URL = None
with open('/app/.env', 'r') as f:
    for line in f:
        if line.startswith('NEXT_PUBLIC_BASE_URL='):
            BASE_URL = line.split('=', 1)[1].strip()
            break

if not BASE_URL:
    print("❌ NEXT_PUBLIC_BASE_URL not found in .env")
    exit(1)

API_BASE = f"{BASE_URL}/api"
print(f"🔗 Testing API at: {API_BASE}\n")

# Test state
test_results = []
buyer_token = None
buyer_cookie = None
buyer_id = None
seller_token = None
seller_cookie = None
seller_id = None
admin_cookie = None
pending_product_id = None
order_id = None

def log_test(name, passed, details=""):
    status = "✅" if passed else "❌"
    test_results.append({"name": name, "passed": passed, "details": details})
    print(f"{status} {name}")
    if details and not passed:
        print(f"   Details: {details}")

def test_health():
    """Test 1: GET /api -> health check"""
    try:
        r = requests.get(API_BASE, timeout=10)
        data = r.json()
        passed = r.status_code == 200 and data.get('name') == 'STYLE MIRROR API' and data.get('status') == 'ok'
        log_test("GET /api health check", passed, f"Status: {r.status_code}, Response: {data}")
        return passed
    except Exception as e:
        log_test("GET /api health check", False, str(e))
        return False

def test_products_list():
    """Test 2: GET /api/products -> 12 seeded approved products"""
    try:
        r = requests.get(f"{API_BASE}/products", timeout=10)
        data = r.json()
        products = data.get('products', [])
        
        # Check we have 12 products
        count_ok = len(products) == 12
        
        # Check all are approved and have required fields
        all_approved = all(p.get('status') == 'approved' for p in products)
        required_fields = ['id', 'name', 'price', 'category', 'image']
        all_have_fields = all(all(f in p for f in required_fields) for p in products)
        
        passed = r.status_code == 200 and count_ok and all_approved and all_have_fields
        details = f"Status: {r.status_code}, Count: {len(products)}, All approved: {all_approved}, Has fields: {all_have_fields}"
        log_test("GET /api/products returns 12 approved products", passed, details)
        return passed, products[0]['id'] if products else None
    except Exception as e:
        log_test("GET /api/products returns 12 approved products", False, str(e))
        return False, None

def test_product_detail(product_id):
    """Test 2b: GET /api/products/:id"""
    try:
        r = requests.get(f"{API_BASE}/products/{product_id}", timeout=10)
        data = r.json()
        passed = r.status_code == 200 and data.get('product', {}).get('id') == product_id
        log_test(f"GET /api/products/{product_id} returns product", passed, f"Status: {r.status_code}")
        
        # Test non-existent product
        r2 = requests.get(f"{API_BASE}/products/doesnotexist", timeout=10)
        not_found = r2.status_code == 404
        log_test("GET /api/products/doesnotexist returns 404", not_found, f"Status: {r2.status_code}")
        
        return passed and not_found
    except Exception as e:
        log_test("GET /api/products/:id", False, str(e))
        return False

def test_auth_register_buyer():
    """Test 3a: POST /api/auth/register as buyer"""
    global buyer_token, buyer_cookie, buyer_id
    try:
        ts = int(time.time())
        email = f"buyer_{ts}@test.com"
        payload = {
            "name": "Test Buyer",
            "email": email,
            "password": "buyer123"
        }
        r = requests.post(f"{API_BASE}/auth/register", json=payload, timeout=10)
        data = r.json()
        
        # Check response
        user = data.get('user', {})
        passed = (r.status_code == 201 and 
                 user.get('role') == 'buyer' and 
                 user.get('email') == email and
                 'token' in data)
        
        # Check cookie is set
        cookie_set = 'sm_token' in r.cookies
        
        if passed and cookie_set:
            buyer_token = data['token']
            buyer_cookie = r.cookies.get('sm_token')
            buyer_id = user.get('id')
        
        details = f"Status: {r.status_code}, Role: {user.get('role')}, Cookie set: {cookie_set}"
        log_test("POST /api/auth/register creates buyer with cookie", passed and cookie_set, details)
        return passed and cookie_set
    except Exception as e:
        log_test("POST /api/auth/register buyer", False, str(e))
        return False

def test_auth_register_seller():
    """Test 3b: POST /api/auth/register as seller"""
    global seller_token, seller_cookie, seller_id
    try:
        ts = int(time.time())
        email = f"seller_{ts}@test.com"
        payload = {
            "name": "Test Seller",
            "email": email,
            "password": "seller123",
            "wantsSeller": True
        }
        r = requests.post(f"{API_BASE}/auth/register", json=payload, timeout=10)
        data = r.json()
        
        user = data.get('user', {})
        passed = (r.status_code == 201 and 
                 user.get('role') == 'seller' and
                 'token' in data)
        
        if passed:
            seller_token = data['token']
            seller_cookie = r.cookies.get('sm_token')
            seller_id = user.get('id')
        
        log_test("POST /api/auth/register with wantsSeller=true creates seller", passed, f"Status: {r.status_code}, Role: {user.get('role')}")
        return passed
    except Exception as e:
        log_test("POST /api/auth/register seller", False, str(e))
        return False

def test_auth_register_validations():
    """Test 3c: Registration validations"""
    try:
        # Duplicate email
        ts = int(time.time())
        email = f"duplicate_{ts}@test.com"
        payload = {"name": "Test", "email": email, "password": "test123"}
        requests.post(f"{API_BASE}/auth/register", json=payload, timeout=10)
        r = requests.post(f"{API_BASE}/auth/register", json=payload, timeout=10)
        dup_check = r.status_code == 409
        log_test("POST /api/auth/register duplicate email returns 409", dup_check, f"Status: {r.status_code}")
        
        # Missing fields
        r2 = requests.post(f"{API_BASE}/auth/register", json={"name": "Test"}, timeout=10)
        missing_check = r2.status_code == 400
        log_test("POST /api/auth/register missing fields returns 400", missing_check, f"Status: {r2.status_code}")
        
        # Short password
        r3 = requests.post(f"{API_BASE}/auth/register", json={"name": "Test", "email": "test@test.com", "password": "12345"}, timeout=10)
        short_pw = r3.status_code == 400
        log_test("POST /api/auth/register short password (<6) returns 400", short_pw, f"Status: {r3.status_code}")
        
        # Bad email
        r4 = requests.post(f"{API_BASE}/auth/register", json={"name": "Test", "email": "bademail", "password": "test123"}, timeout=10)
        bad_email = r4.status_code == 400
        log_test("POST /api/auth/register bad email returns 400", bad_email, f"Status: {r4.status_code}")
        
        return dup_check and missing_check and short_pw and bad_email
    except Exception as e:
        log_test("Registration validations", False, str(e))
        return False

def test_auth_login_admin():
    """Test 3d: POST /api/auth/login as admin"""
    global admin_cookie
    try:
        payload = {
            "email": "admin@stylemirror.com",
            "password": "Admin@123"
        }
        r = requests.post(f"{API_BASE}/auth/login", json=payload, timeout=10)
        data = r.json()
        
        user = data.get('user', {})
        passed = (r.status_code == 200 and 
                 user.get('role') == 'admin' and
                 'token' in data)
        
        if passed:
            admin_cookie = r.cookies.get('sm_token')
        
        log_test("POST /api/auth/login admin credentials returns role=admin", passed, f"Status: {r.status_code}, Role: {user.get('role')}")
        
        # Test wrong password
        r2 = requests.post(f"{API_BASE}/auth/login", json={"email": "admin@stylemirror.com", "password": "wrong"}, timeout=10)
        wrong_pw = r2.status_code == 401
        log_test("POST /api/auth/login wrong password returns 401", wrong_pw, f"Status: {r2.status_code}")
        
        return passed and wrong_pw
    except Exception as e:
        log_test("POST /api/auth/login admin", False, str(e))
        return False

def test_auth_me():
    """Test 3e: GET /api/auth/me"""
    try:
        # With cookie
        cookies = {'sm_token': buyer_cookie}
        r = requests.get(f"{API_BASE}/auth/me", cookies=cookies, timeout=10)
        data = r.json()
        user = data.get('user')
        
        has_user = user is not None
        no_password = 'passwordHash' not in user if user else True
        
        log_test("GET /api/auth/me with cookie returns user without passwordHash", has_user and no_password, 
                f"Status: {r.status_code}, Has user: {has_user}, No passwordHash: {no_password}")
        
        # Without cookie
        r2 = requests.get(f"{API_BASE}/auth/me", timeout=10)
        data2 = r2.json()
        no_user = data2.get('user') is None
        log_test("GET /api/auth/me without cookie returns user=null", no_user, f"User: {data2.get('user')}")
        
        return has_user and no_password and no_user
    except Exception as e:
        log_test("GET /api/auth/me", False, str(e))
        return False

def test_auth_logout():
    """Test 3f: POST /api/auth/logout"""
    try:
        cookies = {'sm_token': buyer_cookie}
        r = requests.post(f"{API_BASE}/auth/logout", cookies=cookies, timeout=10)
        data = r.json()
        
        logout_ok = r.status_code == 200 and data.get('loggedOut') == True
        log_test("POST /api/auth/logout returns success", logout_ok, f"Status: {r.status_code}")
        
        # Check cookie is cleared (maxAge=0 or empty)
        cookie_cleared = r.cookies.get('sm_token') == '' or 'sm_token' in r.cookies
        
        # Verify subsequent /me call returns null
        # Need to use the cleared cookie or no cookie
        r2 = requests.get(f"{API_BASE}/auth/me", cookies={'sm_token': r.cookies.get('sm_token', '')}, timeout=10)
        data2 = r2.json()
        me_null = data2.get('user') is None
        log_test("GET /api/auth/me after logout returns user=null", me_null, f"User: {data2.get('user')}")
        
        return logout_ok and me_null
    except Exception as e:
        log_test("POST /api/auth/logout", False, str(e))
        return False

def test_me_profile_update():
    """Test 4a: PATCH /api/me profile update"""
    try:
        # Re-login buyer to get fresh cookie
        payload = {"email": f"buyer_{int(time.time())}@test.com", "name": "Buyer2", "password": "buyer123"}
        r_reg = requests.post(f"{API_BASE}/auth/register", json=payload, timeout=10)
        cookie = r_reg.cookies.get('sm_token')
        
        # Update profile
        update = {"name": "New Name", "phone": "1234567890", "address": "123 Test St"}
        r = requests.patch(f"{API_BASE}/me", json=update, cookies={'sm_token': cookie}, timeout=10)
        data = r.json()
        
        user = data.get('user', {})
        passed = (r.status_code == 200 and 
                 user.get('name') == 'New Name' and
                 user.get('phone') == '1234567890')
        
        log_test("PATCH /api/me updates profile", passed, f"Status: {r.status_code}, Name: {user.get('name')}")
        return passed
    except Exception as e:
        log_test("PATCH /api/me profile", False, str(e))
        return False

def test_me_password_change():
    """Test 4b: PATCH /api/me password change"""
    try:
        # Create new user
        ts = int(time.time())
        email = f"pwtest_{ts}@test.com"
        payload = {"email": email, "name": "PwTest", "password": "oldpass"}
        r_reg = requests.post(f"{API_BASE}/auth/register", json=payload, timeout=10)
        cookie = r_reg.cookies.get('sm_token')
        
        # Try wrong current password
        r1 = requests.patch(f"{API_BASE}/me", 
                           json={"currentPassword": "wrong", "newPassword": "abcdef"},
                           cookies={'sm_token': cookie}, timeout=10)
        wrong_pw = r1.status_code == 400
        log_test("PATCH /api/me wrong currentPassword returns 400", wrong_pw, f"Status: {r1.status_code}")
        
        # Correct password change
        r2 = requests.patch(f"{API_BASE}/me",
                           json={"currentPassword": "oldpass", "newPassword": "newpass"},
                           cookies={'sm_token': cookie}, timeout=10)
        change_ok = r2.status_code == 200
        log_test("PATCH /api/me correct password change returns 200", change_ok, f"Status: {r2.status_code}")
        
        # Login with new password
        r3 = requests.post(f"{API_BASE}/auth/login", json={"email": email, "password": "newpass"}, timeout=10)
        login_ok = r3.status_code == 200
        log_test("Login with new password works", login_ok, f"Status: {r3.status_code}")
        
        return wrong_pw and change_ok and login_ok
    except Exception as e:
        log_test("PATCH /api/me password change", False, str(e))
        return False

def test_me_tryons_orders():
    """Test 4c: GET /api/me/tryons and /api/me/orders"""
    try:
        cookies = {'sm_token': seller_cookie}
        
        # GET /api/me/tryons
        r1 = requests.get(f"{API_BASE}/me/tryons", cookies=cookies, timeout=10)
        data1 = r1.json()
        tryons_ok = r1.status_code == 200 and 'tryons' in data1
        log_test("GET /api/me/tryons returns tryons array", tryons_ok, f"Status: {r1.status_code}, Has tryons: {'tryons' in data1}")
        
        # GET /api/me/orders
        r2 = requests.get(f"{API_BASE}/me/orders", cookies=cookies, timeout=10)
        data2 = r2.json()
        orders_ok = r2.status_code == 200 and 'orders' in data2
        log_test("GET /api/me/orders returns orders array", orders_ok, f"Status: {r2.status_code}, Has orders: {'orders' in data2}")
        
        # Test unauthenticated
        r3 = requests.get(f"{API_BASE}/me/tryons", timeout=10)
        unauth = r3.status_code == 401
        log_test("GET /api/me/tryons unauthenticated returns 401", unauth, f"Status: {r3.status_code}")
        
        return tryons_ok and orders_ok and unauth
    except Exception as e:
        log_test("GET /api/me/tryons and orders", False, str(e))
        return False

def test_orders_create():
    """Test 5: POST /api/orders"""
    global order_id
    try:
        cookies = {'sm_token': buyer_cookie}
        # Re-login to get fresh buyer cookie
        ts = int(time.time())
        email = f"orderbuyer_{ts}@test.com"
        r_reg = requests.post(f"{API_BASE}/auth/register", 
                             json={"email": email, "name": "OrderBuyer", "password": "buyer123"},
                             timeout=10)
        cookie = r_reg.cookies.get('sm_token')
        buyer_user_id = r_reg.json().get('user', {}).get('id')
        
        order = {
            "items": [{"id": "p1", "name": "Test Product", "price": 89, "qty": 1, "size": "M", "image": "url"}],
            "subtotal": 89,
            "total": 89,
            "shipping": 0,
            "discount": 0
        }
        r = requests.post(f"{API_BASE}/orders", json=order, cookies={'sm_token': cookie}, timeout=10)
        data = r.json()
        
        order_id = data.get('orderId')
        starts_with_sm = order_id and order_id.startswith('SM-')
        
        log_test("POST /api/orders creates order with orderId starting 'SM-'", starts_with_sm, 
                f"Status: {r.status_code}, OrderId: {order_id}")
        
        # Verify order appears in GET /api/me/orders
        r2 = requests.get(f"{API_BASE}/me/orders", cookies={'sm_token': cookie}, timeout=10)
        data2 = r2.json()
        orders = data2.get('orders', [])
        has_order = any(o.get('id') == order_id and o.get('userId') == buyer_user_id for o in orders)
        log_test("GET /api/me/orders returns the created order with userId", has_order, 
                f"Found order: {has_order}, Orders count: {len(orders)}")
        
        return starts_with_sm and has_order
    except Exception as e:
        log_test("POST /api/orders", False, str(e))
        return False

def test_seller_products():
    """Test 6: Seller routes"""
    global pending_product_id
    try:
        cookies = {'sm_token': seller_cookie}
        
        # GET /api/seller/products (should be empty initially)
        r1 = requests.get(f"{API_BASE}/seller/products", cookies=cookies, timeout=10)
        data1 = r1.json()
        empty_ok = r1.status_code == 200 and len(data1.get('products', [])) >= 0
        log_test("GET /api/seller/products returns products array", empty_ok, f"Status: {r1.status_code}")
        
        # POST /api/seller/products (create product)
        # Small 1x1 PNG base64
        tiny_png = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
        product = {
            "name": "Test Jacket",
            "price": 120,
            "category": "Outerwear",
            "brand": "TestBrand",
            "colors": "Black, Grey",
            "sizes": "S, M, L",
            "tags": "new",
            "description": "Test description",
            "image": tiny_png
        }
        r2 = requests.post(f"{API_BASE}/seller/products", json=product, cookies=cookies, timeout=10)
        data2 = r2.json()
        created_product = data2.get('product', {})
        
        create_ok = (r2.status_code == 201 and 
                    created_product.get('status') == 'pending' and
                    created_product.get('sellerId') == seller_id)
        pending_product_id = created_product.get('id')
        
        log_test("POST /api/seller/products creates product with status=pending", create_ok, 
                f"Status: {r2.status_code}, Product status: {created_product.get('status')}, SellerId set: {created_product.get('sellerId') == seller_id}")
        
        # Test missing image
        r3 = requests.post(f"{API_BASE}/seller/products", 
                          json={"name": "Test", "price": 100},
                          cookies=cookies, timeout=10)
        missing_image = r3.status_code == 400
        log_test("POST /api/seller/products missing image returns 400", missing_image, f"Status: {r3.status_code}")
        
        # PUT /api/seller/products/:id (update)
        if pending_product_id:
            r4 = requests.put(f"{API_BASE}/seller/products/{pending_product_id}",
                             json={"price": 130},
                             cookies=cookies, timeout=10)
            data4 = r4.json()
            updated = data4.get('product', {})
            update_ok = (r4.status_code == 200 and 
                        updated.get('price') == 130 and
                        updated.get('status') == 'pending')
            log_test("PUT /api/seller/products/:id updates product, status remains pending", update_ok,
                    f"Status: {r4.status_code}, Price: {updated.get('price')}, Status: {updated.get('status')}")
        
        # Verify pending product NOT in public GET /api/products
        r5 = requests.get(f"{API_BASE}/products", timeout=10)
        data5 = r5.json()
        public_products = data5.get('products', [])
        not_in_public = not any(p.get('id') == pending_product_id for p in public_products)
        log_test("Pending product does NOT appear in GET /api/products", not_in_public,
                f"Found in public: {not not_in_public}")
        
        # GET /api/seller/stats
        r6 = requests.get(f"{API_BASE}/seller/stats", cookies=cookies, timeout=10)
        data6 = r6.json()
        stats = data6.get('stats', {})
        stats_ok = (r6.status_code == 200 and 
                   stats.get('total', 0) >= 1 and
                   stats.get('pending', 0) >= 1)
        log_test("GET /api/seller/stats returns stats with total and pending", stats_ok,
                f"Status: {r6.status_code}, Stats: {stats}")
        
        # Test buyer calling seller routes -> 403
        buyer_cookies = {'sm_token': buyer_cookie}
        # Need fresh buyer cookie
        r_buyer = requests.post(f"{API_BASE}/auth/register",
                               json={"email": f"buyer_forbid_{int(time.time())}@test.com", "name": "B", "password": "buyer123"},
                               timeout=10)
        buyer_cookies = {'sm_token': r_buyer.cookies.get('sm_token')}
        
        r7 = requests.get(f"{API_BASE}/seller/products", cookies=buyer_cookies, timeout=10)
        buyer_forbidden = r7.status_code == 403
        log_test("Buyer calling GET /api/seller/products returns 403", buyer_forbidden, f"Status: {r7.status_code}")
        
        # Test unauthenticated -> 401
        r8 = requests.get(f"{API_BASE}/seller/products", timeout=10)
        unauth = r8.status_code == 401
        log_test("Unauthenticated GET /api/seller/products returns 401", unauth, f"Status: {r8.status_code}")
        
        return create_ok and missing_image and not_in_public and stats_ok and buyer_forbidden and unauth
    except Exception as e:
        log_test("Seller routes", False, str(e))
        return False

def test_seller_ownership():
    """Test 6b: Seller ownership enforcement"""
    try:
        # Create second seller
        ts = int(time.time())
        r_seller2 = requests.post(f"{API_BASE}/auth/register",
                                 json={"email": f"seller2_{ts}@test.com", "name": "Seller2", "password": "seller123", "wantsSeller": True},
                                 timeout=10)
        seller2_cookie = r_seller2.cookies.get('sm_token')
        
        # Try to update first seller's product
        if pending_product_id:
            r = requests.put(f"{API_BASE}/seller/products/{pending_product_id}",
                           json={"price": 999},
                           cookies={'sm_token': seller2_cookie}, timeout=10)
            forbidden = r.status_code == 403
            log_test("Second seller cannot PUT first seller's product (403)", forbidden, f"Status: {r.status_code}")
            
            # Try to delete
            r2 = requests.delete(f"{API_BASE}/seller/products/{pending_product_id}",
                               cookies={'sm_token': seller2_cookie}, timeout=10)
            forbidden2 = r2.status_code == 403
            log_test("Second seller cannot DELETE first seller's product (403)", forbidden2, f"Status: {r2.status_code}")
            
            return forbidden and forbidden2
        return True
    except Exception as e:
        log_test("Seller ownership enforcement", False, str(e))
        return False

def test_admin_stats():
    """Test 7a: GET /api/admin/stats"""
    try:
        cookies = {'sm_token': admin_cookie}
        r = requests.get(f"{API_BASE}/admin/stats", cookies=cookies, timeout=10)
        data = r.json()
        stats = data.get('stats', {})
        
        required_fields = ['users', 'products', 'pendingProducts', 'orders', 'revenue', 'tryons', 'recentOrders']
        has_fields = all(f in stats for f in required_fields)
        has_pending = stats.get('pendingProducts', 0) >= 1
        
        passed = r.status_code == 200 and has_fields and has_pending
        log_test("GET /api/admin/stats returns stats with pendingProducts >= 1", passed,
                f"Status: {r.status_code}, Has fields: {has_fields}, Pending: {stats.get('pendingProducts')}")
        return passed
    except Exception as e:
        log_test("GET /api/admin/stats", False, str(e))
        return False

def test_admin_users():
    """Test 7b: GET /api/admin/users and PATCH"""
    try:
        cookies = {'sm_token': admin_cookie}
        
        # GET /api/admin/users
        r1 = requests.get(f"{API_BASE}/admin/users", cookies=cookies, timeout=10)
        data1 = r1.json()
        users = data1.get('users', [])
        
        no_password = all('passwordHash' not in u for u in users)
        log_test("GET /api/admin/users returns users without passwordHash", no_password,
                f"Status: {r1.status_code}, Users count: {len(users)}, No passwordHash: {no_password}")
        
        # Find a buyer to modify
        buyer_user = next((u for u in users if u.get('role') == 'buyer'), None)
        if not buyer_user:
            # Create one
            ts = int(time.time())
            r_new = requests.post(f"{API_BASE}/auth/register",
                                 json={"email": f"admintest_{ts}@test.com", "name": "AdminTest", "password": "test123"},
                                 timeout=10)
            buyer_user = r_new.json().get('user')
        
        buyer_user_id = buyer_user.get('id')
        
        # PATCH role to seller
        r2 = requests.patch(f"{API_BASE}/admin/users/{buyer_user_id}",
                           json={"role": "seller"},
                           cookies=cookies, timeout=10)
        data2 = r2.json()
        role_updated = data2.get('user', {}).get('role') == 'seller'
        log_test("PATCH /api/admin/users/:id changes role", role_updated,
                f"Status: {r2.status_code}, New role: {data2.get('user', {}).get('role')}")
        
        # PATCH banned=true
        r3 = requests.patch(f"{API_BASE}/admin/users/{buyer_user_id}",
                           json={"banned": True},
                           cookies=cookies, timeout=10)
        data3 = r3.json()
        banned = data3.get('user', {}).get('banned') == True
        log_test("PATCH /api/admin/users/:id sets banned=true", banned,
                f"Status: {r3.status_code}, Banned: {data3.get('user', {}).get('banned')}")
        
        # Try to login as banned user -> 403
        r4 = requests.post(f"{API_BASE}/auth/login",
                          json={"email": buyer_user.get('email'), "password": "test123"},
                          timeout=10)
        suspended = r4.status_code == 403
        log_test("Login as banned user returns 403 (suspended)", suspended, f"Status: {r4.status_code}")
        
        # PATCH banned=false to restore
        r5 = requests.patch(f"{API_BASE}/admin/users/{buyer_user_id}",
                           json={"banned": False},
                           cookies=cookies, timeout=10)
        restored = r5.status_code == 200
        log_test("PATCH /api/admin/users/:id banned=false restores account", restored, f"Status: {r5.status_code}")
        
        # Try to modify own admin account -> 400
        admin_user = next((u for u in users if u.get('role') == 'admin'), None)
        if admin_user:
            r6 = requests.patch(f"{API_BASE}/admin/users/{admin_user.get('id')}",
                               json={"role": "buyer"},
                               cookies=cookies, timeout=10)
            self_modify = r6.status_code == 400
            log_test("PATCH /api/admin/users on own admin id returns 400", self_modify, f"Status: {r6.status_code}")
        
        return no_password and role_updated and banned and suspended and restored
    except Exception as e:
        log_test("GET /api/admin/users and PATCH", False, str(e))
        return False

def test_admin_products():
    """Test 7c: GET /api/admin/products and PATCH/DELETE"""
    try:
        cookies = {'sm_token': admin_cookie}
        
        # GET /api/admin/products (includes pending)
        r1 = requests.get(f"{API_BASE}/admin/products", cookies=cookies, timeout=10)
        data1 = r1.json()
        products = data1.get('products', [])
        has_pending = any(p.get('id') == pending_product_id for p in products)
        log_test("GET /api/admin/products includes pending product", has_pending,
                f"Status: {r1.status_code}, Has pending: {has_pending}")
        
        # PATCH status to approved
        if pending_product_id:
            r2 = requests.patch(f"{API_BASE}/admin/products/{pending_product_id}",
                               json={"status": "approved"},
                               cookies=cookies, timeout=10)
            data2 = r2.json()
            approved = data2.get('product', {}).get('status') == 'approved'
            log_test("PATCH /api/admin/products/:id status=approved", approved,
                    f"Status: {r2.status_code}, Status: {data2.get('product', {}).get('status')}")
            
            # Verify now visible in public GET /api/products
            r3 = requests.get(f"{API_BASE}/products", timeout=10)
            data3 = r3.json()
            public_products = data3.get('products', [])
            now_visible = any(p.get('id') == pending_product_id for p in public_products)
            log_test("Approved product now visible in GET /api/products", now_visible,
                    f"Found in public: {now_visible}")
            
            # PATCH status to rejected
            r4 = requests.patch(f"{API_BASE}/admin/products/{pending_product_id}",
                               json={"status": "rejected"},
                               cookies=cookies, timeout=10)
            rejected = r4.json().get('product', {}).get('status') == 'rejected'
            log_test("PATCH /api/admin/products/:id status=rejected", rejected,
                    f"Status: {r4.status_code}")
            
            # DELETE product
            r5 = requests.delete(f"{API_BASE}/admin/products/{pending_product_id}",
                                cookies=cookies, timeout=10)
            deleted = r5.status_code == 200 and r5.json().get('deleted') == True
            log_test("DELETE /api/admin/products/:id deletes product", deleted,
                    f"Status: {r5.status_code}, Deleted: {r5.json().get('deleted')}")
            
            return approved and now_visible and rejected and deleted
        return False
    except Exception as e:
        log_test("GET /api/admin/products and PATCH/DELETE", False, str(e))
        return False

def test_admin_forbidden():
    """Test 7d: Buyer calling admin routes -> 403"""
    try:
        # Create fresh buyer
        ts = int(time.time())
        r_buyer = requests.post(f"{API_BASE}/auth/register",
                               json={"email": f"buyer_admin_{ts}@test.com", "name": "BuyerAdmin", "password": "buyer123"},
                               timeout=10)
        buyer_cookies = {'sm_token': r_buyer.cookies.get('sm_token')}
        
        r = requests.get(f"{API_BASE}/admin/stats", cookies=buyer_cookies, timeout=10)
        forbidden = r.status_code == 403
        log_test("Buyer calling GET /api/admin/stats returns 403", forbidden, f"Status: {r.status_code}")
        return forbidden
    except Exception as e:
        log_test("Buyer calling admin routes", False, str(e))
        return False

def test_fashion_assist_chat():
    """Test 8a: POST /api/assist/chat"""
    try:
        payload = {
            "message": "Suggest a jacket for a date night",
            "history": [],
            "context": {"page": "/"}
        }
        r = requests.post(f"{API_BASE}/assist/chat", json=payload, timeout=30)
        data = r.json()
        
        has_reply = 'reply' in data and len(str(data.get('reply', ''))) > 0
        has_products = 'products' in data and isinstance(data.get('products'), list)
        
        passed = r.status_code == 200 and has_reply and has_products
        log_test("POST /api/assist/chat returns reply and products array", passed,
                f"Status: {r.status_code}, Has reply: {has_reply}, Has products: {has_products}")
        
        # Test empty message -> 400
        r2 = requests.post(f"{API_BASE}/assist/chat", json={"message": ""}, timeout=10)
        empty_msg = r2.status_code == 400
        log_test("POST /api/assist/chat empty message returns 400", empty_msg, f"Status: {r2.status_code}")
        
        return passed and empty_msg
    except Exception as e:
        log_test("POST /api/assist/chat", False, str(e))
        return False

def test_fashion_assist_analyze():
    """Test 8b: POST /api/assist/analyze with real image"""
    try:
        # Download a real person image
        print("   Downloading test image from Unsplash...")
        img_url = "https://images.unsplash.com/photo-1618886614638-80e3c103d31a?w=600"
        img_response = requests.get(img_url, timeout=30)
        
        if img_response.status_code != 200:
            log_test("POST /api/assist/analyze", False, f"Failed to download test image: {img_response.status_code}")
            return False
        
        # Prepare multipart form
        files = {
            'photo': ('person.jpg', BytesIO(img_response.content), 'image/jpeg'),
        }
        data = {
            'occasion': 'date night'
        }
        
        print("   Sending analyze request (may take 10-25s)...")
        r = requests.post(f"{API_BASE}/assist/analyze", files=files, data=data, timeout=60)
        response_data = r.json()
        
        analysis = response_data.get('analysis', {})
        has_fields = all(f in analysis for f in ['skin_tone', 'body_type', 'style_vibe', 'spoken_summary', 'recommendations'])
        has_recommendations = len(analysis.get('recommendations', [])) > 0
        recommendations_have_products = all('product' in rec for rec in analysis.get('recommendations', []))
        
        passed = (r.status_code == 200 and 
                 has_fields and 
                 has_recommendations and
                 recommendations_have_products)
        
        log_test("POST /api/assist/analyze returns analysis with recommendations", passed,
                f"Status: {r.status_code}, Has fields: {has_fields}, Recommendations count: {len(analysis.get('recommendations', []))}")
        
        # Test non-image file -> 400
        files2 = {'photo': ('test.txt', BytesIO(b'not an image'), 'text/plain')}
        r2 = requests.post(f"{API_BASE}/assist/analyze", files=files2, data={'occasion': 'test'}, timeout=10)
        non_image = r2.status_code == 400
        log_test("POST /api/assist/analyze non-image file returns 400", non_image, f"Status: {r2.status_code}")
        
        # Test missing photo -> 400
        r3 = requests.post(f"{API_BASE}/assist/analyze", data={'occasion': 'test'}, timeout=10)
        missing_photo = r3.status_code == 400
        log_test("POST /api/assist/analyze missing photo returns 400", missing_photo, f"Status: {r3.status_code}")
        
        return passed and non_image and missing_photo
    except Exception as e:
        log_test("POST /api/assist/analyze", False, str(e))
        return False

def test_seller_delete_own_product():
    """Test 9: Seller DELETE /api/seller/products/:id (own product)"""
    try:
        cookies = {'sm_token': seller_cookie}
        
        # Create a new product first
        tiny_png = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
        product = {
            "name": "Delete Test Product",
            "price": 50,
            "category": "Test",
            "image": tiny_png
        }
        r1 = requests.post(f"{API_BASE}/seller/products", json=product, cookies=cookies, timeout=10)
        product_id = r1.json().get('product', {}).get('id')
        
        if not product_id:
            log_test("Seller DELETE own product", False, "Failed to create test product")
            return False
        
        # Delete it
        r2 = requests.delete(f"{API_BASE}/seller/products/{product_id}", cookies=cookies, timeout=10)
        deleted = r2.status_code == 200 and r2.json().get('deleted') == True
        log_test("Seller DELETE /api/seller/products/:id (own) returns deleted=true", deleted,
                f"Status: {r2.status_code}, Deleted: {r2.json().get('deleted')}")
        
        return deleted
    except Exception as e:
        log_test("Seller DELETE own product", False, str(e))
        return False

def main():
    print("=" * 70)
    print("STYLE MIRROR Backend API Test Suite")
    print("=" * 70)
    print()
    
    # Run all tests in order
    test_health()
    print()
    
    print("--- Products Tests ---")
    products_ok, first_product_id = test_products_list()
    if first_product_id:
        test_product_detail(first_product_id)
    print()
    
    print("--- Auth Tests ---")
    test_auth_register_buyer()
    test_auth_register_seller()
    test_auth_register_validations()
    test_auth_login_admin()
    test_auth_me()
    test_auth_logout()
    print()
    
    print("--- Me Routes Tests ---")
    test_me_profile_update()
    test_me_password_change()
    test_me_tryons_orders()
    print()
    
    print("--- Orders Tests ---")
    test_orders_create()
    print()
    
    print("--- Seller Routes Tests ---")
    test_seller_products()
    test_seller_ownership()
    test_seller_delete_own_product()
    print()
    
    print("--- Admin Routes Tests ---")
    test_admin_stats()
    test_admin_users()
    test_admin_products()
    test_admin_forbidden()
    print()
    
    print("--- Fashion Assist Tests ---")
    test_fashion_assist_chat()
    test_fashion_assist_analyze()
    print()
    
    # Summary
    print("=" * 70)
    print("TEST SUMMARY")
    print("=" * 70)
    passed = sum(1 for t in test_results if t['passed'])
    total = len(test_results)
    print(f"Passed: {passed}/{total}")
    print()
    
    if passed < total:
        print("Failed tests:")
        for t in test_results:
            if not t['passed']:
                print(f"  ❌ {t['name']}")
                if t['details']:
                    print(f"     {t['details']}")
    else:
        print("🎉 All tests passed!")
    
    print()
    print("=" * 70)

if __name__ == "__main__":
    main()

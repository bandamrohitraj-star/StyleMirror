# STYLE MIRROR — PRD / Working Notes

## Product
AI-powered men's fashion eCommerce with virtual try-on (Gemini 3.1 Flash Image via Emergent key), role-based accounts
(buyer / seller / admin) and "Mirror", an animated voice-enabled AI stylist mascot present on every page.

## Stack
Next.js 15 App Router (JS), Tailwind + shadcn/ui, Framer Motion, MongoDB (UUID ids), jose JWT (httpOnly cookie `sm_token`),
bcryptjs, Emergent LLM gateway (gemini-2.5-flash for vision/chat with fallbacks, gemini-3.1-flash-image-preview for try-on),
Web Speech API (TTS male voice + STT).

## Routes
- `/` SPA storefront (landing, shop, product, try-on studio, history) — supports `/?view=tryon&id=p2` deep links
- `/login`, `/register` — role-aware redirect (buyer→/buyer, seller→/seller, admin→/admin)
- `/buyer` profile · saved try-ons · orders | `/seller` product CRUD + approval status | `/admin` stats · users · products · orders
- `/about` tech stack page

## API (all under /api, see app/api/[[...path]]/route.js)
auth/{register,login,logout,me} · me, me/tryons, me/orders · products · seller/products[/id], seller/stats ·
admin/{stats,users[/id],products[/id],orders} · try-on · history · orders · assist/{analyze,chat}

## Credentials
admin@stylemirror.com / Admin@123 (auto-seeded). See /app/memory/test_credentials.md

## Status
- Backend: tested 53/54 (only "minor" was a test-order artefact).
- Frontend: visually verified landing, login→admin redirect, mascot click reaction, chat panel. Full UI test pending user approval.

## Backlog
Stripe checkout, cloud storage (Cloudinary/S3) for images instead of data URLs, Prisma/Postgres migration (original PRD),
product reviews, wishlist persistence per user, seller analytics.

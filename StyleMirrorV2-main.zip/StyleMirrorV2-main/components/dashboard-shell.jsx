'use client'
import React, { useEffect } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import { motion } from 'framer-motion'
import { SiteHeader } from '@/components/site-header'
import { useAuth, ROLE_HOME } from '@/components/auth-context'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'

const cn = (...c) => c.filter(Boolean).join(' ')

/**
 * Shared chrome for the role dashboards. Guards the route: redirects to /login when logged out
 * and to the user's own dashboard when they lack the required role.
 */
export function DashboardShell({ allow, eyebrow, title, subtitle, tabs = [], active, onTabChange, children, aside }) {
  const { user, loading } = useAuth()
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    if (loading) return
    if (!user) { router.replace(`/login?next=${encodeURIComponent(pathname)}`); return }
    if (allow && !allow.includes(user.role)) router.replace(ROLE_HOME[user.role] || '/')
  }, [user, loading, allow, router, pathname])

  const allowed = user && (!allow || allow.includes(user.role))

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100">
      <SiteHeader />
      <div className="pt-28 pb-24">
        <div className="container mx-auto max-w-7xl px-6">
          <div className="mb-10 flex flex-wrap items-end justify-between gap-6">
            <div>
              {eyebrow && <div className="text-xs tracking-widest text-neutral-500 uppercase mb-2">{eyebrow}</div>}
              <h1 className="font-display text-5xl md:text-6xl">{title}</h1>
              {subtitle && <p className="text-neutral-400 mt-2 max-w-xl">{subtitle}</p>}
            </div>
            {aside}
          </div>
          {tabs.length > 0 && (
            <div className="flex gap-1 mb-8 overflow-x-auto border-b border-white/10">
              {tabs.map(t => (
                <button key={t.key} onClick={() => onTabChange?.(t.key)} data-testid={`tab-${t.key}`}
                  className={cn('relative px-4 py-3 text-sm whitespace-nowrap transition inline-flex items-center gap-2', active === t.key ? 'text-white' : 'text-neutral-500 hover:text-neutral-200')}>
                  {t.icon && <t.icon className="w-4 h-4" />}{t.label}
                  {t.count !== undefined && <Badge className="bg-white/10 text-white hover:bg-white/10 text-[10px] px-1.5 py-0">{t.count}</Badge>}
                  {active === t.key && <motion.div layoutId="dash-tab" className="absolute bottom-0 inset-x-0 h-0.5 bg-gradient-to-r from-amber-200 to-violet-300" />}
                </button>
              ))}
            </div>
          )}
          {loading || !allowed ? (
            <div className="grid md:grid-cols-3 gap-6">{Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-40 rounded-3xl bg-white/5" />)}</div>
          ) : children}
        </div>
      </div>
    </div>
  )
}

export function StatCard({ label, value, hint, icon: Icon, accent }) {
  return (
    <div className="glass rounded-3xl p-6 relative overflow-hidden">
      {Icon && <div className={cn('w-10 h-10 rounded-2xl flex items-center justify-center mb-4 bg-white/5', accent)}><Icon className="w-5 h-5 text-amber-100" /></div>}
      <div className="text-3xl font-display">{value}</div>
      <div className="text-sm text-neutral-400 mt-1">{label}</div>
      {hint && <div className="text-xs text-neutral-600 mt-2">{hint}</div>}
    </div>
  )
}

export const inputCls = 'bg-white/5 border-white/10 rounded-xl text-neutral-100 placeholder:text-neutral-600 focus-visible:ring-amber-200/40'

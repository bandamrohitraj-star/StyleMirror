'use client'
import React, { useEffect, useRef, useState } from 'react'
import { toast } from 'sonner'
import { Loader2, Upload, CheckCircle2, Clock, XCircle, Wand2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { inputCls } from '@/components/dashboard-shell'

const CATEGORIES = ['T-Shirts', 'Shirts', 'Sweats', 'Outerwear', 'Tailoring', 'Trousers', 'Denim', 'Footwear', 'Accessories', 'Other']
const STATUS = {
  approved: { label: 'Live', cls: 'bg-emerald-400/15 text-emerald-300 border-emerald-400/20', icon: CheckCircle2 },
  pending: { label: 'Pending review', cls: 'bg-amber-300/15 text-amber-200 border-amber-300/20', icon: Clock },
  rejected: { label: 'Rejected', cls: 'bg-rose-400/15 text-rose-300 border-rose-400/20', icon: XCircle },
}
export function StatusBadge({ status }) { const s = STATUS[status] || STATUS.pending; const I = s.icon; return <Badge className={`border ${s.cls} hover:${s.cls} gap-1`}><I className="w-3 h-3" />{s.label}</Badge> }

function fileToDataUrl(file, max = 1000) {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.onload = () => {
      const s = Math.min(1, max / Math.max(img.width, img.height))
      const c = document.createElement('canvas'); c.width = Math.round(img.width * s); c.height = Math.round(img.height * s)
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height)
      resolve(c.toDataURL('image/jpeg', 0.82))
    }
    img.onerror = reject
    img.src = URL.createObjectURL(file)
  })
}

export function ProductDialog({ product, onClose, onSaved, endpoint = '/api/seller/products' }) {
  const isNew = product && !product.id
  const [form, setForm] = useState(null)
  const [busy, setBusy] = useState(false)
  const fileRef = useRef(null)
  useEffect(() => {
    if (!product) { setForm(null); return }
    setForm({ name: product.name || '', price: product.price || '', category: product.category || 'T-Shirts', brand: product.brand || '', colors: (product.colors || []).join(', '), sizes: (product.sizes || []).join(', '), tags: (product.tags || []).join(', '), description: product.description || '', image: product.image || '' })
  }, [product])
  const onFile = async (f) => { if (!f) return; try { const url = await fileToDataUrl(f); setForm(x => ({ ...x, image: url })) } catch { toast.error('Could not read image') } }
  const save = async () => {
    if (!form.name || !form.price || !form.image) return toast.error('Name, price and an image are required')
    setBusy(true)
    try {
      const r = await fetch(isNew ? endpoint : `${endpoint}/${product.id}`, { method: isNew ? 'POST' : 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) })
      const d = await r.json(); if (!r.ok) throw new Error(d.error || 'Save failed')
      toast.success(isNew ? 'Product submitted for review' : 'Product updated', { description: isNew ? 'An admin will approve it shortly.' : 'Edits are re-reviewed before going live.' })
      onSaved?.(d.product)
    } catch (e) { toast.error(e.message) } finally { setBusy(false) }
  }
  return (
    <Dialog open={!!product} onOpenChange={(o) => { if (!o) onClose() }}>
      <DialogContent className="bg-neutral-950 border-white/10 text-neutral-100 sm:max-w-3xl max-h-[90vh] overflow-y-auto rounded-3xl">
        <DialogHeader>
          <DialogTitle className="font-display text-3xl">{isNew ? 'New product' : 'Edit product'}</DialogTitle>
          <DialogDescription className="text-neutral-500">Clean, front-facing product photos on plain backgrounds produce the best AI try-ons.</DialogDescription>
        </DialogHeader>
        {form && (
          <div className="grid md:grid-cols-[260px_1fr] gap-6 mt-2">
            <div>
              <button type="button" onClick={() => fileRef.current?.click()} className="relative w-full aspect-[3/4] rounded-2xl overflow-hidden border border-dashed border-white/20 bg-white/5 hover:border-white/40 transition flex items-center justify-center" data-testid="product-image-drop">
                {form.image ? <img src={form.image} alt="" className="w-full h-full object-cover" /> : <div className="text-center p-6 text-neutral-400"><Upload className="w-7 h-7 mx-auto mb-2 text-amber-100" /><div className="text-sm">Upload image</div><div className="text-xs text-neutral-600 mt-1">JPG / PNG, auto-compressed</div></div>}
                {form.image && <div className="absolute bottom-3 inset-x-3"><div className="glass rounded-full h-9 flex items-center justify-center text-xs"><Upload className="w-3.5 h-3.5 mr-1.5" /> Replace</div></div>}
              </button>
              <input ref={fileRef} type="file" accept="image/*" hidden onChange={e => onFile(e.target.files?.[0])} data-testid="product-image-input" />
              <div className="mt-3 text-[11px] text-neutral-500 flex items-start gap-1.5"><Wand2 className="w-3.5 h-3.5 mt-0.5 text-amber-100 flex-shrink-0" /> Buyers will be able to try this on with AI once approved.</div>
            </div>
            <div className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2"><Label className="text-xs tracking-widest text-neutral-500 uppercase">Name</Label><Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Onyx Oversized Tee" className={inputCls} data-testid="product-name" /></div>
                <div className="space-y-2"><Label className="text-xs tracking-widest text-neutral-500 uppercase">Price (USD)</Label><Input type="number" min="0" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} placeholder="89" className={inputCls} data-testid="product-price" /></div>
                <div className="space-y-2"><Label className="text-xs tracking-widest text-neutral-500 uppercase">Category</Label>
                  <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v }))}>
                    <SelectTrigger className={inputCls} data-testid="product-category"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-neutral-900 border-white/10 text-neutral-100">{CATEGORIES.map(c => <SelectItem key={c} value={c} className="focus:bg-white/10 focus:text-white">{c}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-2"><Label className="text-xs tracking-widest text-neutral-500 uppercase">Brand</Label><Input value={form.brand} onChange={e => setForm(f => ({ ...f, brand: e.target.value }))} placeholder="Your label" className={inputCls} /></div>
                <div className="space-y-2"><Label className="text-xs tracking-widest text-neutral-500 uppercase">Colors</Label><Input value={form.colors} onChange={e => setForm(f => ({ ...f, colors: e.target.value }))} placeholder="Black, Charcoal" className={inputCls} /></div>
                <div className="space-y-2"><Label className="text-xs tracking-widest text-neutral-500 uppercase">Sizes</Label><Input value={form.sizes} onChange={e => setForm(f => ({ ...f, sizes: e.target.value }))} placeholder="S, M, L, XL" className={inputCls} /></div>
              </div>
              <div className="space-y-2"><Label className="text-xs tracking-widest text-neutral-500 uppercase">Tags</Label><Input value={form.tags} onChange={e => setForm(f => ({ ...f, tags: e.target.value }))} placeholder="new, trending" className={inputCls} /></div>
              <div className="space-y-2"><Label className="text-xs tracking-widest text-neutral-500 uppercase">Description</Label><Textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Fabric, fit, and what makes it special." className={inputCls + ' min-h-[100px]'} data-testid="product-description" /></div>
              <div className="flex gap-3 pt-2">
                <Button onClick={save} disabled={busy} className="flex-1 rounded-full bg-white text-neutral-900 hover:bg-neutral-200 h-12" data-testid="product-save">{busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}{isNew ? 'Submit for review' : 'Save product'}</Button>
                <Button variant="outline" onClick={onClose} className="rounded-full border-white/20 bg-transparent hover:bg-white/5 h-12 px-6">Cancel</Button>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

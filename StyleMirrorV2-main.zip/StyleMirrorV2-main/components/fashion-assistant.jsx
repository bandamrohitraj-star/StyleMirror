'use client'
import React, { useCallback, useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { usePathname, useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Sparkles, X, Volume2, VolumeX, Mic, MicOff, Send, Upload, Camera, Wand2, RefreshCw, Loader2, MessageCircle, ScanFace } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'

const W = 88, H = 124
const cn = (...c) => c.filter(Boolean).join(' ')
const clamp = (v, a, b) => Math.max(a, Math.min(b, v))
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)]

// What Mirror says when you click things. First matching rule wins.
const CLICK_LINES = [
  [/generate/i, ['Hold still. Working my magic.', 'Fitting it on you now. Give me about fifteen seconds.']],
  [/try.?on|see it on you/i, ["Let's see how that looks on you.", 'Great choice. Into the studio we go.', 'Trying it on. This is my favourite part.']],
  [/add to bag|add to cart/i, ['Excellent pick. Into the bag it goes.', 'Added. That one is going to look sharp.']],
  [/checkout/i, ['Wrapping this up for you. Nice haul.']],
  [/capture/i, ['Smile. Stand back so I can see the full outfit.']],
  [/camera/i, ["Let's use the camera. Step back a little so I see head to toe."]],
  [/upload|change photo/i, ['Pick a clear, full-body photo for the best result.']],
  [/compare/i, ['Before and after. Slide to compare.']],
  [/download|save/i, ['Saved. Show it off.']],
  [/share/i, ['Sharing the look. Your friends will want one too.']],
  [/regenerate/i, ['One more take. Let me refine it.']],
  [/shop|collection|view all/i, ["Let's browse the collection together.", 'Plenty of pieces to pull for you here.']],
  [/history/i, ['Here are all the looks you have tried.']],
  [/sign in|log in|login/i, ['Welcome back. Let me pull up your wardrobe.']],
  [/create account|register|sign up/i, ["Let's set you up. It only takes a moment."]],
  [/sign out|logout/i, ['See you soon. I will keep your looks safe.']],
  [/approve/i, ['Approved. That piece goes live in the shop.']],
  [/reject|ban|remove|delete/i, ['Done. Taken care of.']],
  [/publish|save product|add product|new product/i, ['Listing it now. Buyers can try it on with AI once approved.']],
  [/filter|sort|price|rating/i, ['Narrowing it down for you.']],
  [/menu/i, ['Menu, coming right up.']],
]
const GENERIC_LINES = ['On it.', 'Got it.', 'Pulling that for you.', "Let's go.", 'Right away.', 'Good call.']
const PAGE_LINES = {
  '/login': 'Sign in and I will remember every look you try.',
  '/register': 'Create an account so I can save your try-ons and orders.',
  '/buyer': "Here's your wardrobe hub. Profile, try-ons and orders, all in one place.",
  '/seller': 'Welcome to your seller console. Add a product and I will make it try-on ready.',
  '/admin': 'Admin mode. Everything at a glance.',
  '/about': 'Curious how I am built? Here is the whole stack.',
}

export function FashionAssistant() {
  const pathname = usePathname()
  const router = useRouter()
  const [pos, setPos] = useState({ x: -200, y: -200 })
  const [dur, setDur] = useState(0.6)
  const [mode, setMode] = useState('idle') // idle | walk | run | pull | look | think
  const [facing, setFacing] = useState('right')
  const [talking, setTalking] = useState(false)
  const [bubble, setBubble] = useState(null)
  const [open, setOpen] = useState(false)
  const [muted, setMuted] = useState(false)
  const [eye, setEye] = useState({ x: 0, y: 0 })
  const posRef = useRef({ x: -200, y: -200 })
  const pendingRef = useRef(null)
  const bubbleTimer = useRef(null)
  const idleTimer = useRef(null)
  const lastReact = useRef(0)
  const interacted = useRef(false)
  const openRef = useRef(false)
  const mutedRef = useRef(false)
  const modeRef = useRef('idle')
  useEffect(() => { openRef.current = open }, [open])
  useEffect(() => { mutedRef.current = muted }, [muted])
  useEffect(() => { modeRef.current = mode }, [mode])

  // ---------- Voice ----------
  const pickVoice = () => {
    if (typeof speechSynthesis === 'undefined') return null
    const voices = speechSynthesis.getVoices() || []
    const en = voices.filter(v => /^en/i.test(v.lang))
    const male = en.find(v => /male|david|mark|guy|daniel|alex|fred|george|james|ryan|aaron|christopher|eric|brian|rishi|oliver/i.test(v.name) && !/female|zira|susan|samantha|karen|moira|tessa|fiona|victoria/i.test(v.name))
    return male || en.find(v => /Google UK English Male/i.test(v.name)) || en[0] || voices[0] || null
  }
  useEffect(() => { if (typeof speechSynthesis !== 'undefined') { speechSynthesis.getVoices(); speechSynthesis.onvoiceschanged = () => speechSynthesis.getVoices() } }, [])

  const say = useCallback((text, { silent = false } = {}) => {
    if (!text) return
    const shown = text.length > 170 ? text.slice(0, 167).trimEnd() + '…' : text
    setBubble(shown)
    clearTimeout(bubbleTimer.current)
    bubbleTimer.current = setTimeout(() => setBubble(null), clamp(2200 + shown.length * 55, 2500, 9000))
    if (silent || mutedRef.current || typeof speechSynthesis === 'undefined' || !interacted.current) return
    try {
      speechSynthesis.cancel()
      const u = new SpeechSynthesisUtterance(text)
      const v = pickVoice(); if (v) u.voice = v
      u.pitch = 0.78; u.rate = 1.02; u.volume = 1
      u.onstart = () => setTalking(true)
      u.onend = () => setTalking(false)
      u.onerror = () => setTalking(false)
      speechSynthesis.speak(u)
    } catch {}
  }, [])

  // ---------- Movement ----------
  const moveTo = useCallback((x, y, after) => {
    const vw = window.innerWidth, vh = window.innerHeight
    const cx = clamp(x, 4, vw - W - 4), cy = clamp(y, 70, vh - H - 4)
    const dist = Math.hypot(cx - posRef.current.x, cy - posRef.current.y)
    if (dist < 8) { after?.(); return }
    const run = dist > 460
    const d = clamp(dist / (run ? 1000 : 420), 0.3, 2.2)
    setFacing(cx < posRef.current.x ? 'left' : 'right')
    setMode(run ? 'run' : 'walk')
    pendingRef.current = after || null
    setDur(d); setPos({ x: cx, y: cy }); posRef.current = { x: cx, y: cy }
  }, [])

  const onArrive = () => {
    const a = pendingRef.current; pendingRef.current = null
    if (a) a(); else setMode('idle')
  }

  const homeSpot = useCallback(() => ({ x: window.innerWidth - W - 24, y: window.innerHeight - H - 28 }), [])

  const goToElement = useCallback((el, then) => {
    const r = el.getBoundingClientRect()
    const vw = window.innerWidth
    let x = r.left - W - 6
    if (x < 4) x = r.right + 6
    if (x + W > vw - 4) x = clamp(r.left + r.width / 2 - W / 2, 4, vw - W - 4)
    const y = r.bottom - H + 6
    moveTo(x, y, () => {
      const rr = el.getBoundingClientRect()
      setFacing(posRef.current.x + W / 2 < rr.left + rr.width / 2 ? 'right' : 'left')
      then?.(rr)
    })
  }, [moveTo])

  const nudge = (el, dir) => {
    try {
      const t = getComputedStyle(el).transform
      if (t && t !== 'none') return
      el.style.transition = 'transform .18s ease'
      el.style.transform = `translateX(${dir === 'right' ? -5 : 5}px) rotate(${dir === 'right' ? -1 : 1}deg)`
      setTimeout(() => { el.style.transform = ''; setTimeout(() => { el.style.transition = '' }, 200) }, 260)
    } catch {}
  }

  // ---------- Initial placement + home ----------
  useEffect(() => {
    const h = homeSpot()
    posRef.current = h; setPos(h); setDur(0)
    const t = setTimeout(() => say("Hi, I'm Mirror, your personal stylist. Click me anytime for a style check.", { silent: true }), 900)
    const onResize = () => { const hs = homeSpot(); posRef.current = { x: clamp(posRef.current.x, 4, hs.x), y: clamp(posRef.current.y, 70, hs.y) }; setPos({ ...posRef.current }) }
    window.addEventListener('resize', onResize)
    return () => { clearTimeout(t); window.removeEventListener('resize', onResize) }
  }, [homeSpot, say])

  // ---------- Idle wandering ----------
  useEffect(() => {
    const tick = () => {
      if (openRef.current || modeRef.current !== 'idle' || document.hidden) return
      const vw = window.innerWidth, vh = window.innerHeight
      moveTo(40 + Math.random() * (vw - W - 80), vh - H - 28 - Math.random() * 30)
    }
    idleTimer.current = setInterval(tick, 16000)
    return () => clearInterval(idleTimer.current)
  }, [moveTo])

  // ---------- Eyes follow the mouse ----------
  useEffect(() => {
    let raf = 0
    const h = (e) => {
      cancelAnimationFrame(raf)
      raf = requestAnimationFrame(() => {
        const cx = posRef.current.x + W / 2, cy = posRef.current.y + 32
        const dx = e.clientX - cx, dy = e.clientY - cy
        const len = Math.hypot(dx, dy) || 1
        setEye({ x: (dx / len) * 2.2 * (facing === 'left' ? -1 : 1), y: (dy / len) * 1.8 })
      })
    }
    window.addEventListener('mousemove', h)
    return () => { window.removeEventListener('mousemove', h); cancelAnimationFrame(raf) }
  }, [facing])

  // ---------- React to every click ----------
  useEffect(() => {
    const handler = (e) => {
      const target = e.target
      if (!(target instanceof Element)) return
      if (target.closest('[data-mascot]')) { interacted.current = true; return }
      interacted.current = true
      const el = target.closest('button, a, [role="button"], label, summary, .cursor-pointer, input[type="checkbox"], input[type="radio"]')
      const now = Date.now()
      if (!el) return
      if (now - lastReact.current < 500) return
      lastReact.current = now
      const text = (el.getAttribute('aria-label') || el.textContent || el.getAttribute('title') || '').trim().slice(0, 80)
      const rule = CLICK_LINES.find(([re]) => re.test(text))
      const line = rule ? pick(rule[1]) : pick(GENERIC_LINES)
      goToElement(el, (rr) => {
        setMode('pull')
        nudge(el, posRef.current.x + W / 2 < rr.left + rr.width / 2 ? 'right' : 'left')
        say(line)
        setTimeout(() => setMode(m => (m === 'pull' ? 'idle' : m)), 900)
      })
    }
    document.addEventListener('click', handler, true)
    return () => document.removeEventListener('click', handler, true)
  }, [goToElement, say])

  // ---------- App events (try-on lifecycle etc.) ----------
  useEffect(() => {
    const handler = (e) => {
      const { type, product } = e.detail || {}
      if (type === 'tryon-start') { setMode('think'); say('Working on it. Fitting the garment, matching the light, keeping it you.') }
      if (type === 'tryon-error') { setMode('idle'); say('Hmm, that one did not render. Try a clearer, full-body photo.') }
      if (type === 'tryon-result') {
        setTimeout(() => {
          const el = document.querySelector('[data-tryon-result]')
          const name = product?.name ? `that ${product.name}` : 'that piece'
          if (!el) { say(`Looking sharp. ${name} really suits you.`); return }
          goToElement(el, () => {
            setMode('look')
            say(`Looking sharp. ${name[0].toUpperCase()}${name.slice(1)} really suits you. Slide to compare before and after, or add it to your bag.`)
            setTimeout(() => setMode(m => (m === 'look' ? 'idle' : m)), 5000)
          })
        }, 350)
      }
      if (type === 'say' && e.detail.text) say(e.detail.text)
    }
    window.addEventListener('mirror:event', handler)
    return () => window.removeEventListener('mirror:event', handler)
  }, [goToElement, say])

  // ---------- Page change ----------
  useEffect(() => {
    const line = PAGE_LINES[pathname]
    if (line) setTimeout(() => say(line), 600)
    moveTo(homeSpot().x, homeSpot().y)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname])

  const togglePanel = () => {
    interacted.current = true
    setOpen(o => {
      const next = !o
      if (next) say(pick(["Let's do a style check. Upload a photo or just ask me anything.", 'Show me your look and I will pull the right pieces.']))
      return next
    })
  }
  // Stand beside the panel like a presenter while it is open; go home when it closes.
  const wasOpen = useRef(false)
  useEffect(() => {
    if (open) {
      const panelW = Math.min(400, window.innerWidth - 32)
      const t = setTimeout(() => moveTo(window.innerWidth - panelW - 16 - W - 10, window.innerHeight - H - 28), 50)
      wasOpen.current = true
      return () => clearTimeout(t)
    }
    if (wasOpen.current) { wasOpen.current = false; const t = setTimeout(() => moveTo(homeSpot().x, homeSpot().y), 50); return () => clearTimeout(t) }
  }, [open, moveTo, homeSpot])

  const onRight = typeof window !== 'undefined' && pos.x > window.innerWidth / 2

  return (
    <>
      {/* The mascot */}
      <motion.div
        data-mascot
        className="fixed left-0 top-0 z-[90] pointer-events-none select-none"
        style={{ width: W, height: H }}
        animate={{ x: pos.x, y: pos.y }}
        transition={{ duration: dur, ease: 'linear' }}
        onAnimationComplete={onArrive}
      >
        <AnimatePresence>
          {bubble && (
            <motion.div key={bubble} initial={{ opacity: 0, y: 6, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 4 }}
              className={cn('absolute bottom-full mb-2 w-[230px] glass rounded-2xl px-3.5 py-2.5 text-[13px] leading-snug text-neutral-100 shadow-2xl', onRight ? 'right-0' : 'left-0')}
              data-testid="mascot-bubble">
              {bubble}
              <div className={cn('absolute -bottom-1.5 w-3 h-3 rotate-45 bg-neutral-900/80 border-r border-b border-white/10', onRight ? 'right-6' : 'left-6')} />
            </motion.div>
          )}
        </AnimatePresence>
        <button onClick={togglePanel} aria-label="Open Mirror, your AI stylist" data-testid="mascot" className="pointer-events-auto cursor-pointer w-full h-full outline-none focus-visible:ring-2 ring-amber-200/60 rounded-2xl">
          <Mascot mode={mode} facing={facing} talking={talking} eye={eye} />
        </button>
        <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-14 h-2 rounded-full bg-black/60 blur-sm" />
      </motion.div>

      {/* The panel */}
      <AnimatePresence>
        {open && (
          <motion.div data-mascot initial={{ opacity: 0, y: 24, scale: 0.96 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 16, scale: 0.97 }} transition={{ duration: 0.25 }}
            className="fixed bottom-4 right-4 z-[95] w-[400px] max-w-[calc(100vw-2rem)] max-h-[82vh] glass rounded-3xl shadow-2xl flex flex-col overflow-hidden" style={{ background: 'rgba(12,12,12,0.86)' }} data-testid="assist-panel">
            <AssistPanel onClose={() => setOpen(false)} muted={muted} setMuted={setMuted} say={say} router={router} pathname={pathname} setMode={setMode} />
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

// ---------- SVG character ----------
function Mascot({ mode, facing, talking, eye }) {
  return (
    <div className="mascot w-full h-full" data-mode={mode} data-talking={talking} style={{ transform: facing === 'left' ? 'scaleX(-1)' : 'none' }}>
      <svg viewBox="0 0 88 124" width={W} height={H} className="drop-shadow-[0_8px_16px_rgba(0,0,0,0.6)]">
        <defs>
          <linearGradient id="m-face" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="45%" stopColor="#e9d8bd" />
            <stop offset="100%" stopColor="#a78bfa" />
          </linearGradient>
          <linearGradient id="m-suit" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#2a2a2a" />
            <stop offset="100%" stopColor="#111" />
          </linearGradient>
          <linearGradient id="m-tie" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#f5d9a6" />
            <stop offset="100%" stopColor="#a78bfa" />
          </linearGradient>
        </defs>
        <g className="m-body" style={{ transformOrigin: '44px 84px', transformBox: 'view-box' }}>
          {/* legs */}
          <g className="m-leg m-leg-l" style={{ transformOrigin: '38px 82px', transformBox: 'view-box' }}>
            <rect x="33" y="80" width="10" height="30" rx="4" fill="#1b1b1b" />
            <rect x="30" y="106" width="16" height="7" rx="3.5" fill="#f3f3f3" />
          </g>
          <g className="m-leg m-leg-r" style={{ transformOrigin: '50px 82px', transformBox: 'view-box' }}>
            <rect x="45" y="80" width="10" height="30" rx="4" fill="#232323" />
            <rect x="42" y="106" width="16" height="7" rx="3.5" fill="#ffffff" />
          </g>
          {/* torso / suit */}
          <path d="M26 56 Q26 50 32 49 L56 49 Q62 50 62 56 L62 84 Q62 88 58 88 L30 88 Q26 88 26 84 Z" fill="url(#m-suit)" stroke="#3a3a3a" strokeWidth="1" />
          <path d="M34 49 L44 66 L54 49 Z" fill="#0b0b0b" />
          <path d="M34 49 L44 66 L39 50 Z" fill="#d4b896" opacity="0.9" />
          <path d="M54 49 L44 66 L49 50 Z" fill="#d4b896" opacity="0.9" />
          <path d="M44 52 L47 56 L44 72 L41 56 Z" fill="url(#m-tie)" />
          <circle cx="36" cy="72" r="1.4" fill="#d4b896" />
          {/* arms */}
          <g className="m-arm m-arm-l" style={{ transformOrigin: '29px 56px', transformBox: 'view-box' }}>
            <rect x="24" y="52" width="8" height="28" rx="4" fill="#1d1d1d" />
            <circle cx="28" cy="82" r="4.5" fill="#e7cdb0" />
          </g>
          <g className="m-arm m-arm-r" style={{ transformOrigin: '59px 56px', transformBox: 'view-box' }}>
            <rect x="56" y="52" width="8" height="28" rx="4" fill="#262626" />
            <circle cx="60" cy="82" r="4.5" fill="#efd6ba" />
          </g>
          {/* head */}
          <g className="m-head" style={{ transformOrigin: '44px 46px', transformBox: 'view-box' }}>
            <rect x="29" y="14" width="30" height="34" rx="12" fill="url(#m-face)" stroke="rgba(255,255,255,0.7)" strokeWidth="1" />
            <path d="M33 20 Q38 16 46 17" stroke="rgba(255,255,255,0.8)" strokeWidth="1.5" fill="none" strokeLinecap="round" />
            {/* flat cap */}
            <path d="M27 20 Q44 4 61 20 L62 23 L26 23 Z" fill="#161616" />
            <path d="M26 23 L66 23 Q66 26 62 26 L28 26 Q25 26 26 23 Z" fill="#0a0a0a" />
            {/* eyes */}
            <g style={{ transform: `translate(${eye.x}px, ${eye.y}px)` }}>
              <circle cx="38.5" cy="33" r="2.6" fill="#0a0a0a" />
              <circle cx="49.5" cy="33" r="2.6" fill="#0a0a0a" />
              <circle cx="39.4" cy="32.2" r="0.8" fill="#fff" />
              <circle cx="50.4" cy="32.2" r="0.8" fill="#fff" />
            </g>
            {/* mouth */}
            <rect className="m-mouth" x="40" y="40" width="8" height="2.4" rx="1.2" fill="#0a0a0a" style={{ transformOrigin: '44px 41px', transformBox: 'view-box' }} />
          </g>
        </g>
      </svg>
    </div>
  )
}

// ---------- Panel ----------
function AssistPanel({ onClose, muted, setMuted, say, router, pathname, setMode }) {
  const [tab, setTab] = useState('analyze')
  return (
    <>
      <div className="flex items-center gap-3 px-5 pt-4 pb-3 border-b border-white/10">
        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-white via-amber-100 to-violet-300 flex items-center justify-center flex-shrink-0"><Sparkles className="w-4 h-4 text-neutral-900" /></div>
        <div className="min-w-0 flex-1">
          <div className="font-display text-lg leading-none">Mirror</div>
          <div className="text-[11px] text-neutral-500 mt-1">Your AI stylist · voice on {muted ? 'mute' : 'speaker'}</div>
        </div>
        <Button variant="ghost" size="icon" onClick={() => { setMuted(m => !m); if (typeof speechSynthesis !== 'undefined') speechSynthesis.cancel() }} className="text-neutral-300 hover:text-white hover:bg-white/5 h-8 w-8" aria-label={muted ? 'Unmute Mirror' : 'Mute Mirror'} data-testid="mute-toggle">{muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}</Button>
        <Button variant="ghost" size="icon" onClick={onClose} className="text-neutral-300 hover:text-white hover:bg-white/5 h-8 w-8" aria-label="Close" data-testid="assist-close"><X className="w-4 h-4" /></Button>
      </div>
      <div className="px-5 pt-3 flex gap-1">
        {[['analyze', 'Analyze my look', ScanFace], ['chat', 'Ask Mirror', MessageCircle]].map(([k, l, I]) => (
          <button key={k} onClick={() => setTab(k)} data-testid={`assist-tab-${k}`} className={cn('flex-1 h-9 rounded-full text-xs font-medium inline-flex items-center justify-center gap-1.5 transition', tab === k ? 'bg-white text-neutral-900' : 'bg-white/5 text-neutral-300 hover:bg-white/10')}><I className="w-3.5 h-3.5" />{l}</button>
        ))}
      </div>
      <div className="p-5 overflow-y-auto flex-1">
        {tab === 'analyze' ? <AnalyzeTab say={say} router={router} onClose={onClose} setMode={setMode} /> : <ChatTab say={say} router={router} pathname={pathname} onClose={onClose} setMode={setMode} />}
      </div>
    </>
  )
}

function compressImage(file, max = 1024) {
  return new Promise((resolve) => {
    const img = new Image()
    img.onload = () => {
      const s = Math.min(1, max / Math.max(img.width, img.height))
      const c = document.createElement('canvas'); c.width = Math.round(img.width * s); c.height = Math.round(img.height * s)
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height)
      c.toBlob(b => resolve(new File([b], 'look.jpg', { type: 'image/jpeg' })), 'image/jpeg', 0.86)
    }
    img.onerror = () => resolve(file)
    img.src = URL.createObjectURL(file)
  })
}

function AnalyzeTab({ say, router, onClose, setMode }) {
  const [file, setFile] = useState(null)
  const [preview, setPreview] = useState(null)
  const [occasion, setOccasion] = useState('')
  const [busy, setBusy] = useState(false)
  const [result, setResult] = useState(null)
  const [camera, setCamera] = useState(false)
  const inputRef = useRef(null); const videoRef = useRef(null); const streamRef = useRef(null)

  useEffect(() => () => streamRef.current?.getTracks().forEach(t => t.stop()), [])
  const onFile = async (f) => { if (!f) return; const c = await compressImage(f); setFile(c); setPreview(URL.createObjectURL(c)); setResult(null) }
  const startCam = async () => {
    try { const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } }); streamRef.current = s; setCamera(true); setTimeout(() => { if (videoRef.current) videoRef.current.srcObject = s }, 80) }
    catch { toast.error('Camera unavailable. Upload a photo instead.') }
  }
  const capture = () => {
    const v = videoRef.current; const c = document.createElement('canvas'); c.width = v.videoWidth; c.height = v.videoHeight
    c.getContext('2d').drawImage(v, 0, 0)
    c.toBlob(b => { onFile(new File([b], 'cam.jpg', { type: 'image/jpeg' })); streamRef.current?.getTracks().forEach(t => t.stop()); setCamera(false) }, 'image/jpeg', 0.9)
  }
  const analyze = async () => {
    if (!file) return
    setBusy(true); setMode('think'); say('Let me take a proper look at you.')
    try {
      const fd = new FormData(); fd.append('photo', file); if (occasion) fd.append('occasion', occasion)
      const r = await fetch('/api/assist/analyze', { method: 'POST', body: fd })
      const d = await r.json()
      if (!r.ok) throw new Error(d.error || 'Analysis failed')
      setResult(d.analysis)
      say(d.analysis.spoken_summary)
    } catch (e) { toast.error(e.message); say('I could not read that photo. Try one with better light.') }
    finally { setBusy(false); setMode('idle') }
  }
  const tryOn = (p) => { onClose(); say(`Trying the ${p.name} on you.`); router.push(`/?view=tryon&id=${p.id}`) }

  return (
    <div className="space-y-4">
      {!result && (
        <>
          <div className="relative rounded-2xl overflow-hidden bg-neutral-900 border border-white/10 aspect-[4/3] flex items-center justify-center">
            {camera ? (
              <>
                <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                <div className="absolute bottom-3 inset-x-3 flex justify-center gap-2">
                  <Button size="sm" variant="outline" onClick={() => { streamRef.current?.getTracks().forEach(t => t.stop()); setCamera(false) }} className="rounded-full border-white/20 bg-black/40">Cancel</Button>
                  <Button size="sm" onClick={capture} className="rounded-full bg-white text-neutral-900 hover:bg-neutral-200"><Camera className="w-4 h-4 mr-1" /> Capture</Button>
                </div>
              </>
            ) : preview ? (
              <img src={preview} alt="your look" className="w-full h-full object-cover" />
            ) : (
              <div className="text-center p-6">
                <ScanFace className="w-8 h-8 text-amber-100 mx-auto mb-3" />
                <div className="text-sm font-medium mb-1">Show me your look</div>
                <div className="text-xs text-neutral-500">I will read your skin tone, build and vibe, then pull pieces that suit you.</div>
              </div>
            )}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => inputRef.current?.click()} className="flex-1 rounded-full border-white/15 bg-transparent hover:bg-white/5 h-10 text-xs" data-testid="assist-upload"><Upload className="w-3.5 h-3.5 mr-1.5" /> {preview ? 'Change photo' : 'Upload photo'}</Button>
            <Button variant="outline" onClick={startCam} className="flex-1 rounded-full border-white/15 bg-transparent hover:bg-white/5 h-10 text-xs"><Camera className="w-3.5 h-3.5 mr-1.5" /> Use camera</Button>
            <input ref={inputRef} type="file" accept="image/*" hidden onChange={e => onFile(e.target.files?.[0])} data-testid="assist-file-input" />
          </div>
          <Input value={occasion} onChange={e => setOccasion(e.target.value)} placeholder="Occasion (optional) · e.g. date night, office, wedding" className="bg-white/5 border-white/10 rounded-full text-sm" data-testid="assist-occasion" />
          <Button disabled={!file || busy} onClick={analyze} className="w-full rounded-full h-11 bg-gradient-to-r from-amber-200 to-violet-300 text-neutral-900 hover:opacity-90 disabled:opacity-40 font-medium" data-testid="assist-analyze-btn">
            {busy ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Reading your look…</> : <><Wand2 className="w-4 h-4 mr-2" /> Analyze my look</>}
          </Button>
        </>
      )}
      {result && (
        <div className="space-y-4" data-testid="assist-result">
          <div className="flex gap-3 items-start">
            {preview && <img src={preview} alt="" className="w-16 h-20 object-cover rounded-xl border border-white/10" />}
            <div className="grid grid-cols-2 gap-2 flex-1 text-xs">
              <div className="glass rounded-xl p-2.5"><div className="text-neutral-500 text-[10px] uppercase tracking-wider">Skin tone</div><div className="capitalize">{result.skin_tone?.category} · {result.skin_tone?.undertone}</div></div>
              <div className="glass rounded-xl p-2.5"><div className="text-neutral-500 text-[10px] uppercase tracking-wider">Build</div><div className="capitalize">{result.body_type?.category}</div></div>
              <div className="glass rounded-xl p-2.5 col-span-2"><div className="text-neutral-500 text-[10px] uppercase tracking-wider">Vibe</div><div>{result.style_vibe}</div></div>
            </div>
          </div>
          {result.palette?.length > 0 && <div className="flex flex-wrap gap-1.5">{result.palette.map((c, i) => <Badge key={i} className="bg-white/10 text-white hover:bg-white/10 text-[10px] font-normal">{c}</Badge>)}</div>}
          <p className="text-sm text-neutral-200 leading-relaxed">{result.spoken_summary}</p>
          {result.tips?.length > 0 && <ul className="text-xs text-neutral-400 space-y-1 list-disc pl-4">{result.tips.map((t, i) => <li key={i}>{t}</li>)}</ul>}
          <div>
            <div className="text-[10px] tracking-widest text-neutral-500 uppercase mb-2">Pulled for you</div>
            <div className="space-y-2">
              {result.recommendations?.map(r => r.product && (
                <div key={r.productId} className="flex gap-3 glass rounded-2xl p-2.5 items-center">
                  <img src={r.product.image} alt="" className="w-12 h-14 object-cover rounded-lg flex-shrink-0" />
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-medium truncate">{r.product.name} <span className="text-neutral-500">· ${r.product.price}</span></div>
                    <div className="text-[11px] text-neutral-400 line-clamp-2">{r.reason}</div>
                  </div>
                  <Button size="sm" onClick={() => tryOn(r.product)} className="rounded-full bg-white text-neutral-900 hover:bg-neutral-200 h-8 text-[11px] px-3 flex-shrink-0"><Wand2 className="w-3 h-3 mr-1" />Try on</Button>
                </div>
              ))}
            </div>
          </div>
          {result.limitations?.length > 0 && <p className="text-[10px] text-neutral-600">{result.limitations.join(' ')}</p>}
          <Button variant="outline" onClick={() => { setResult(null) }} className="w-full rounded-full border-white/15 bg-transparent hover:bg-white/5 h-10 text-xs"><RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Analyze another photo</Button>
        </div>
      )}
    </div>
  )
}

function ChatTab({ say, router, pathname, onClose, setMode }) {
  const [messages, setMessages] = useState([{ role: 'assistant', content: 'Ask me anything. What to wear, how to pair a piece, or which fit suits you.' }])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [listening, setListening] = useState(false)
  const recRef = useRef(null); const endRef = useRef(null)
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])
  const supportsSTT = typeof window !== 'undefined' && (window.SpeechRecognition || window.webkitSpeechRecognition)

  const send = async (text) => {
    const msg = (text ?? input).trim(); if (!msg || busy) return
    setInput(''); setBusy(true); setMode('think')
    const history = messages.filter(m => m.role !== 'system').map(m => ({ role: m.role, content: m.content }))
    setMessages(m => [...m, { role: 'user', content: msg }])
    try {
      const r = await fetch('/api/assist/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: msg, history, context: { page: pathname } }) })
      const d = await r.json()
      if (!r.ok) throw new Error(d.error || 'Failed')
      setMessages(m => [...m, { role: 'assistant', content: d.reply, products: d.products || [] }])
      say(d.reply)
    } catch (e) { setMessages(m => [...m, { role: 'assistant', content: 'I lost my train of thought. Ask me again?' }]); toast.error(e.message) }
    finally { setBusy(false); setMode('idle') }
  }
  const toggleListen = () => {
    if (!supportsSTT) return toast.error('Voice input is not supported in this browser. Try Chrome.')
    if (listening) { recRef.current?.stop(); setListening(false); return }
    const R = window.SpeechRecognition || window.webkitSpeechRecognition
    const rec = new R(); rec.lang = 'en-US'; rec.interimResults = true; rec.continuous = false
    rec.onresult = (e) => { const t = Array.from(e.results).map(r => r[0].transcript).join(' '); setInput(t); if (e.results[e.results.length - 1].isFinal) { setListening(false); send(t) } }
    rec.onend = () => setListening(false); rec.onerror = () => { setListening(false); toast.error('Could not hear you. Try again.') }
    recRef.current = rec; rec.start(); setListening(true)
    if (typeof speechSynthesis !== 'undefined') speechSynthesis.cancel()
    say("I'm listening.", { silent: true })
  }
  return (
    <div className="flex flex-col h-[420px]">
      <div className="flex-1 overflow-y-auto space-y-3 pr-1" data-testid="chat-messages">
        {messages.map((m, i) => (
          <div key={i} className={cn('flex', m.role === 'user' ? 'justify-end' : 'justify-start')}>
            <div className={cn('max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm leading-snug', m.role === 'user' ? 'bg-white text-neutral-900' : 'glass text-neutral-100')}>
              {m.content}
              {m.products?.length > 0 && (
                <div className="mt-2 space-y-1.5">
                  {m.products.map(p => (
                    <button key={p.id} onClick={() => { onClose(); router.push(`/?view=tryon&id=${p.id}`) }} className="w-full flex items-center gap-2 bg-white/5 hover:bg-white/10 rounded-xl p-1.5 text-left">
                      <img src={p.image} alt="" className="w-8 h-10 object-cover rounded-md" />
                      <div className="min-w-0 flex-1"><div className="text-xs truncate">{p.name}</div><div className="text-[10px] text-neutral-500">${p.price} · tap to try on</div></div>
                      <Wand2 className="w-3.5 h-3.5 text-amber-100 mr-1" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
        {busy && <div className="flex justify-start"><div className="glass rounded-2xl px-3.5 py-2.5 text-sm text-neutral-400 inline-flex items-center gap-2"><Loader2 className="w-3.5 h-3.5 animate-spin" /> Mirror is thinking…</div></div>}
        <div ref={endRef} />
      </div>
      <form onSubmit={e => { e.preventDefault(); send() }} className="mt-3 flex gap-2 items-center">
        <Button type="button" variant="outline" size="icon" onClick={toggleListen} aria-label="Speak to Mirror" data-testid="mic-btn" className={cn('rounded-full border-white/15 bg-transparent hover:bg-white/5 h-10 w-10 flex-shrink-0', listening && 'bg-rose-500/20 border-rose-400 text-rose-200 animate-pulse')}>{listening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}</Button>
        <Input value={input} onChange={e => setInput(e.target.value)} placeholder={listening ? 'Listening…' : 'Ask Mirror anything'} className="bg-white/5 border-white/10 rounded-full text-sm" data-testid="chat-input" />
        <Button type="submit" size="icon" disabled={busy || !input.trim()} aria-label="Send" data-testid="chat-send" className="rounded-full bg-white text-neutral-900 hover:bg-neutral-200 h-10 w-10 flex-shrink-0 disabled:opacity-40"><Send className="w-4 h-4" /></Button>
      </form>
    </div>
  )
}

export default FashionAssistant

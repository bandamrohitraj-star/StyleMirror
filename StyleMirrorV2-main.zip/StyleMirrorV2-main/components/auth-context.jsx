'use client'
import React, { createContext, useCallback, useContext, useEffect, useState } from 'react'

export const ROLE_HOME = { buyer: '/buyer', seller: '/seller', admin: '/admin' }
const AuthCtx = createContext({ user: null, loading: true })

async function api(path, opts = {}) {
  const r = await fetch(path, { headers: { 'Content-Type': 'application/json' }, cache: 'no-store', ...opts })
  const d = await r.json().catch(() => ({}))
  if (!r.ok) throw new Error(d.error || 'Request failed')
  return d
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  const refresh = useCallback(async () => {
    try { const d = await api('/api/auth/me'); setUser(d.user || null) }
    catch { setUser(null) }
    finally { setLoading(false) }
  }, [])
  useEffect(() => { refresh() }, [refresh])

  const login = useCallback(async (email, password) => {
    const d = await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) })
    setUser(d.user); return d.user
  }, [])
  const register = useCallback(async (payload) => {
    const d = await api('/api/auth/register', { method: 'POST', body: JSON.stringify(payload) })
    setUser(d.user); return d.user
  }, [])
  const logout = useCallback(async () => {
    await fetch('/api/auth/logout', { method: 'POST' }).catch(() => {})
    setUser(null)
  }, [])

  return <AuthCtx.Provider value={{ user, loading, login, register, logout, refresh, setUser }}>{children}</AuthCtx.Provider>
}

export const useAuth = () => useContext(AuthCtx)

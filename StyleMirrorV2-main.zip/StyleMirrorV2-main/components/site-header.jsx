'use client'
import React, { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Sparkles, LogOut, LayoutDashboard, User, Menu, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { useAuth, ROLE_HOME } from '@/components/auth-context'

const cn = (...c) => c.filter(Boolean).join(' ')

export function Logo({ className }) {
  return (
    <Link href="/" className={cn('flex items-center gap-2', className)}>
      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-white via-amber-100 to-violet-300 flex items-center justify-center"><Sparkles className="w-4 h-4 text-neutral-900" /></div>
      <span className="font-display text-xl tracking-wider">STYLE MIRROR</span>
    </Link>
  )
}

export function AccountMenu() {
  const { user, loading, logout } = useAuth()
  const router = useRouter()
  if (loading) return <div className="w-9 h-9 rounded-full bg-white/5 animate-pulse" />
  if (!user) return (
    <Button asChild variant="outline" className="border-white/20 bg-transparent hover:bg-white/10 text-white rounded-full h-9 px-4 text-sm" data-testid="header-signin">
      <Link href="/login"><User className="w-4 h-4 mr-1.5" /> Sign in</Link>
    </Button>
  )
  const initial = (user.name || user.email || '?').charAt(0).toUpperCase()
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button data-testid="account-menu" className="w-9 h-9 rounded-full bg-gradient-to-br from-amber-200 to-violet-300 text-neutral-900 font-semibold text-sm flex items-center justify-center ring-2 ring-white/10 hover:ring-white/30 transition">{initial}</button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="bg-neutral-900 border-white/10 text-neutral-100 w-56">
        <DropdownMenuLabel className="font-normal">
          <div className="text-sm font-medium truncate">{user.name}</div>
          <div className="text-xs text-neutral-500 truncate">{user.email}</div>
          <Badge className="mt-2 capitalize bg-white/10 text-white hover:bg-white/10 text-[10px]">{user.role}</Badge>
        </DropdownMenuLabel>
        <DropdownMenuSeparator className="bg-white/10" />
        <DropdownMenuItem onClick={() => router.push(ROLE_HOME[user.role] || '/buyer')} className="focus:bg-white/10 focus:text-white cursor-pointer"><LayoutDashboard className="w-4 h-4 mr-2" /> My dashboard</DropdownMenuItem>
        {user.role === 'admin' && <DropdownMenuItem onClick={() => router.push('/seller')} className="focus:bg-white/10 focus:text-white cursor-pointer"><LayoutDashboard className="w-4 h-4 mr-2" /> Seller console</DropdownMenuItem>}
        <DropdownMenuItem onClick={() => router.push('/buyer')} className="focus:bg-white/10 focus:text-white cursor-pointer"><User className="w-4 h-4 mr-2" /> Profile & try-ons</DropdownMenuItem>
        <DropdownMenuSeparator className="bg-white/10" />
        <DropdownMenuItem onClick={async () => { await logout(); router.push('/') }} className="focus:bg-white/10 focus:text-white cursor-pointer text-rose-300" data-testid="logout-btn"><LogOut className="w-4 h-4 mr-2" /> Sign out</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

// Header for the standalone routes (login, dashboards, about). The landing SPA keeps its own header.
export function SiteHeader() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  useEffect(() => { const h = () => setScrolled(window.scrollY > 20); h(); window.addEventListener('scroll', h); return () => window.removeEventListener('scroll', h) }, [])
  const links = [
    { href: '/?view=shop', label: 'Shop' },
    { href: '/?view=tryon', label: 'Try-On Studio', ai: true },
    { href: '/?view=history', label: 'History' },
    { href: '/about', label: 'Tech' },
  ]
  return (
    <header className={cn('fixed top-0 inset-x-0 z-50 transition-all duration-500', scrolled ? 'bg-neutral-950/80 backdrop-blur-xl border-b border-white/5' : 'bg-transparent')}>
      <div className="container mx-auto max-w-7xl flex items-center justify-between px-6 py-4">
        <Logo />
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-neutral-300">
          {links.map(l => (
            <Link key={l.href} href={l.href} className="hover:text-white transition inline-flex items-center gap-1.5">{l.label}{l.ai && <Badge className="bg-gradient-to-r from-amber-200 to-violet-300 text-neutral-900 text-[10px] px-1.5 py-0 hover:opacity-90">AI</Badge>}</Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <AccountMenu />
          <Button variant="ghost" size="icon" className="md:hidden text-neutral-300" onClick={() => setOpen(o => !o)}>{open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}</Button>
        </div>
      </div>
      {open && (
        <div className="md:hidden bg-neutral-950/95 backdrop-blur-xl border-t border-white/5 px-6 py-6 space-y-4 text-lg">
          {links.map(l => <Link key={l.href} href={l.href} onClick={() => setOpen(false)} className="block hover:text-amber-200">{l.label}</Link>)}
        </div>
      )}
    </header>
  )
}

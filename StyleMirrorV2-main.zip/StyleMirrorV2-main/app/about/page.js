import Link from 'next/link'
import { Sparkles, Layers, Database, Lock, Wand2, Mic, Bot, Palette, Server, ArrowRight } from 'lucide-react'
import { SiteHeader } from '@/components/site-header'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'

export const metadata = { title: 'Tech stack — STYLE MIRROR' }

const STACK = [
  { icon: Layers, title: 'Framework', items: [['Next.js 15 (App Router)', 'Pages, route handlers and the catch-all /api backend in one codebase'], ['React 18', 'Client components for all interactive UI'], ['Node.js runtime', 'Route handlers run on the Node runtime for FormData + Buffer image handling']] },
  { icon: Palette, title: 'UI & motion', items: [['Tailwind CSS 3', 'Utility-first styling; dark neutral palette with amber → violet accents'], ['shadcn/ui + Radix primitives', 'Buttons, dialogs, dropdowns, tables, selects, sheets, sliders'], ['Framer Motion 11', 'Page transitions, mascot movement (walk / run), panel animations'], ['CSS keyframes', 'Mascot limb cycles: walk, run, pull, look, think, talk'], ['Lucide React', 'Icon set'], ['Sonner', 'Toast notifications']] },
  { icon: Database, title: 'Data', items: [['MongoDB 6 driver', 'Collections: users, products, orders, tryOnHistory, fashionAnalyses'], ['UUID v4 ids', 'All documents use UUIDs (never ObjectId) so they serialise cleanly'], ['Auto-seeding', 'Admin account and men\'s catalog are inserted on first API call']] },
  { icon: Lock, title: 'Auth & roles', items: [['Email + password', 'bcryptjs hashing (10 rounds)'], ['JWT sessions (jose, HS256)', '7-day token in an httpOnly, SameSite=Lax cookie “sm_token”'], ['Role-based routing', 'buyer → /buyer, seller → /seller, admin → /admin; server-side role checks on every protected route'], ['Moderation', 'Admins can change roles, ban users and approve / reject / remove products']] },
  { icon: Wand2, title: 'AI — virtual try-on', items: [['Gemini 3.1 Flash Image', 'Image-to-image garment fitting that preserves identity, pose and lighting'], ['Emergent Universal LLM key', 'Single key routed through the OpenAI-compatible Emergent gateway'], ['Before / after compare', 'Interactive slider over the generated render']] },
  { icon: Bot, title: 'AI — Mirror, the stylist', items: [['Gemini 2.5 Flash (vision)', 'Reads skin tone, build and vibe from a photo and returns structured JSON with product picks'], ['Gemini 2.5 Flash (chat)', 'Short spoken-friendly answers with catalog-aware recommendations'], ['Model fallback chain', 'Playbook models (gemini-3.8-flash / 3.5-flash-lite) are retried automatically when enabled on the gateway'], ['Reactive mascot', 'Listens to every click, walks or runs to the element, “pulls” it, and walks over to inspect try-on results']] },
  { icon: Mic, title: 'Voice', items: [['Web Speech API — SpeechSynthesis', 'Browser-native male voice selection with mute toggle; no API key needed'], ['Web Speech API — SpeechRecognition', 'Push-to-talk voice input that auto-sends to Mirror (Chrome / Edge / Safari)']] },
  { icon: Server, title: 'Infra & tooling', items: [['Yarn 1', 'Dependency management'], ['Supervisor', 'Process manager for the Next.js dev server'], ['Kubernetes ingress', '/api/* routed to the Next.js backend'], ['Client-side image compression', 'Canvas resize before upload to keep payloads small']] },
]

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100">
      <SiteHeader />
      <div className="pt-32 pb-24">
        <div className="container mx-auto max-w-6xl px-6">
          <Badge className="mb-4 bg-white/10 border border-white/20 text-white hover:bg-white/10"><Sparkles className="w-3 h-3 mr-1.5" /> Under the hood</Badge>
          <h1 className="font-display text-5xl md:text-7xl mb-4">Technologies behind <span className="italic gradient-text">STYLE MIRROR</span>.</h1>
          <p className="text-neutral-400 text-lg max-w-2xl mb-14">Everything that powers the store, the AI try-on studio, the role dashboards, and Mirror, the voice-enabled stylist that walks the site with you.</p>
          <div className="grid md:grid-cols-2 gap-6">
            {STACK.map(s => (
              <div key={s.title} className="glass rounded-3xl p-8">
                <div className="flex items-center gap-3 mb-6"><div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-white/10 to-white/5 flex items-center justify-center"><s.icon className="w-5 h-5 text-amber-100" /></div><h2 className="font-display text-2xl">{s.title}</h2></div>
                <ul className="space-y-3">{s.items.map(([t, d]) => (<li key={t} className="flex gap-3"><div className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-amber-200 to-violet-300 mt-2 flex-shrink-0" /><div><div className="text-sm font-medium">{t}</div><div className="text-sm text-neutral-400 leading-relaxed">{d}</div></div></li>))}</ul>
              </div>
            ))}
          </div>
          <div className="mt-14 glass rounded-3xl p-8 md:p-10 grid md:grid-cols-2 gap-6 items-center">
            <div><h3 className="font-display text-3xl mb-2">See it in action.</h3><p className="text-neutral-400">Upload a photo in the studio, or click Mirror in the corner and ask for a style check.</p></div>
            <div className="flex gap-3 md:justify-end flex-wrap">
              <Button asChild className="bg-white text-neutral-900 hover:bg-neutral-200 rounded-full h-12 px-6"><Link href="/?view=tryon"><Wand2 className="w-4 h-4 mr-2" /> Try-On Studio</Link></Button>
              <Button asChild variant="outline" className="border-white/20 bg-transparent hover:bg-white/10 rounded-full h-12 px-6"><Link href="/register">Create account <ArrowRight className="w-4 h-4 ml-2" /></Link></Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

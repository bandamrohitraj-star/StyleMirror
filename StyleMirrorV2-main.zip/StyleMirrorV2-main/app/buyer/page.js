'use client'
import React, { useCallback, useEffect, useState } from 'react'
import Link from 'next/link'
import { toast } from 'sonner'
import { User, Wand2, Package, Download, Trash2, Save, Loader2, History, ShoppingBag, Lock } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Textarea } from '@/components/ui/textarea'
import { useAuth } from '@/components/auth-context'
import { DashboardShell, StatCard, inputCls } from '@/components/dashboard-shell'

export default function BuyerPage() {
  const [tab, setTab] = useState('profile')
  const [tryons, setTryons] = useState(null)
  const [orders, setOrders] = useState(null)
  const { user } = useAuth()

  const load = useCallback(async () => {
    if (!user) return
    const [t, o] = await Promise.all([
      fetch('/api/me/tryons', { cache: 'no-store' }).then(r => r.json()).catch(() => ({})),
      fetch('/api/me/orders', { cache: 'no-store' }).then(r => r.json()).catch(() => ({})),
    ])
    setTryons(t.tryons || []); setOrders(o.orders || [])
  }, [user])
  useEffect(() => { load() }, [load])

  const tabs = [
    { key: 'profile', label: 'Profile', icon: User },
    { key: 'tryons', label: 'Saved try-ons', icon: Wand2, count: tryons?.length },
    { key: 'orders', label: 'Orders', icon: Package, count: orders?.length },
  ]

  return (
    <DashboardShell allow={['buyer', 'seller', 'admin']} eyebrow="Buyer" title={user ? `Hey, ${user.name.split(' ')[0]}.` : 'Your wardrobe'} subtitle="Your profile, every look you have tried on, and your orders in one place."
      tabs={tabs} active={tab} onTabChange={setTab}
      aside={<Button asChild className="bg-white text-neutral-900 hover:bg-neutral-200 rounded-full h-11 px-6"><Link href="/?view=tryon"><Wand2 className="w-4 h-4 mr-2" /> Open Try-On Studio</Link></Button>}>
      <div className="grid md:grid-cols-3 gap-4 mb-10">
        <StatCard icon={Wand2} label="Looks generated" value={tryons ? tryons.length : '—'} />
        <StatCard icon={ShoppingBag} label="Orders placed" value={orders ? orders.length : '—'} />
        <StatCard icon={Package} label="Total spent" value={orders ? `$${orders.reduce((s, o) => s + (Number(o.total) || 0), 0).toFixed(0)}` : '—'} />
      </div>
      {tab === 'profile' && <ProfileTab />}
      {tab === 'tryons' && <TryonsTab items={tryons} setItems={setTryons} />}
      {tab === 'orders' && <OrdersTab orders={orders} />}
    </DashboardShell>
  )
}

function ProfileTab() {
  const { user, setUser } = useAuth()
  const [form, setForm] = useState({ name: '', phone: '', address: '' })
  const [pw, setPw] = useState({ currentPassword: '', newPassword: '' })
  const [busy, setBusy] = useState(false)
  useEffect(() => { if (user) setForm({ name: user.name || '', phone: user.phone || '', address: user.address || '' }) }, [user])
  const save = async (payload) => {
    setBusy(true)
    try {
      const r = await fetch('/api/me', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
      const d = await r.json(); if (!r.ok) throw new Error(d.error)
      setUser(d.user); toast.success('Profile updated'); setPw({ currentPassword: '', newPassword: '' })
    } catch (e) { toast.error(e.message) } finally { setBusy(false) }
  }
  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <div className="glass rounded-3xl p-8">
        <h3 className="font-display text-2xl mb-6">Personal details</h3>
        <div className="space-y-4">
          <div className="space-y-2"><Label className="text-xs tracking-widest text-neutral-500 uppercase">Full name</Label><Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className={inputCls} data-testid="profile-name" /></div>
          <div className="space-y-2"><Label className="text-xs tracking-widest text-neutral-500 uppercase">Email</Label><Input value={user?.email || ''} disabled className={inputCls + ' opacity-60'} /></div>
          <div className="space-y-2"><Label className="text-xs tracking-widest text-neutral-500 uppercase">Phone</Label><Input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="+1 …" className={inputCls} data-testid="profile-phone" /></div>
          <div className="space-y-2"><Label className="text-xs tracking-widest text-neutral-500 uppercase">Shipping address</Label><Textarea value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} placeholder="Street, city, postcode, country" className={inputCls + ' min-h-[90px]'} data-testid="profile-address" /></div>
          <Button disabled={busy} onClick={() => save(form)} className="rounded-full bg-white text-neutral-900 hover:bg-neutral-200 h-11 px-6" data-testid="profile-save">{busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />} Save changes</Button>
        </div>
      </div>
      <div className="space-y-6">
        <div className="glass rounded-3xl p-8">
          <h3 className="font-display text-2xl mb-2">Security</h3>
          <p className="text-sm text-neutral-500 mb-6">Change your password.</p>
          <div className="space-y-4">
            <div className="relative"><Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" /><Input type="password" value={pw.currentPassword} onChange={e => setPw(p => ({ ...p, currentPassword: e.target.value }))} placeholder="Current password" className={inputCls + ' pl-11'} /></div>
            <div className="relative"><Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" /><Input type="password" value={pw.newPassword} onChange={e => setPw(p => ({ ...p, newPassword: e.target.value }))} placeholder="New password (min 6)" className={inputCls + ' pl-11'} /></div>
            <Button variant="outline" disabled={busy || !pw.currentPassword || !pw.newPassword} onClick={() => save(pw)} className="rounded-full border-white/20 bg-transparent hover:bg-white/5 h-11 px-6">Update password</Button>
          </div>
        </div>
        <div className="glass rounded-3xl p-8">
          <div className="flex items-center justify-between"><h3 className="font-display text-2xl">Membership</h3><Badge className="capitalize bg-gradient-to-r from-amber-200 to-violet-300 text-neutral-900 hover:opacity-90">{user?.role}</Badge></div>
          <p className="text-sm text-neutral-500 mt-2">Member since {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : '—'}. Free returns for 365 days on every order.</p>
        </div>
      </div>
    </div>
  )
}

function TryonsTab({ items, setItems }) {
  const remove = async (id) => { await fetch(`/api/history/${id}`, { method: 'DELETE' }); setItems(x => x.filter(i => i.id !== id)); toast.success('Removed') }
  if (!items) return <div className="grid grid-cols-2 md:grid-cols-4 gap-6">{Array(4).fill(0).map((_, i) => <Skeleton key={i} className="aspect-[3/4] rounded-2xl bg-white/5" />)}</div>
  if (items.length === 0) return (
    <div className="glass rounded-3xl p-16 text-center">
      <History className="w-12 h-12 mx-auto mb-4 text-neutral-600" />
      <h3 className="font-display text-2xl mb-2">No saved looks yet</h3>
      <p className="text-neutral-500 mb-6">Try-ons you generate while signed in land here automatically.</p>
      <Button asChild className="bg-white text-neutral-900 hover:bg-neutral-200 rounded-full h-12 px-6"><Link href="/?view=tryon"><Wand2 className="w-4 h-4 mr-2" /> Open Studio</Link></Button>
    </div>
  )
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6" data-testid="tryons-grid">
      {items.map(it => (
        <div key={it.id} className="group relative aspect-[3/4] rounded-2xl overflow-hidden bg-neutral-900">
          <img src={it.resultDataUrl} className="w-full h-full object-cover" alt="" />
          <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-0 group-hover:opacity-100 transition" />
          <div className="absolute bottom-0 inset-x-0 p-3 opacity-0 group-hover:opacity-100 transition">
            <div className="text-xs text-neutral-300 mb-1 truncate">{it.product?.name || 'Custom garment'}</div>
            <div className="flex gap-2">
              {it.product?.id && <Link href={`/?view=tryon&id=${it.product.id}`} className="flex-1 h-8 rounded-full bg-white text-neutral-900 text-xs flex items-center justify-center gap-1 hover:bg-neutral-200"><Wand2 className="w-3 h-3" />Again</Link>}
              <a href={it.resultDataUrl} download={`stylemirror-${it.id}.png`} className="w-8 h-8 rounded-full bg-black/60 text-neutral-200 flex items-center justify-center hover:bg-black/80"><Download className="w-3 h-3" /></a>
              <button onClick={() => remove(it.id)} className="w-8 h-8 rounded-full bg-black/60 text-neutral-300 flex items-center justify-center hover:bg-black/80"><Trash2 className="w-3 h-3" /></button>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

function OrdersTab({ orders }) {
  if (!orders) return <Skeleton className="h-40 rounded-3xl bg-white/5" />
  if (orders.length === 0) return (
    <div className="glass rounded-3xl p-16 text-center">
      <Package className="w-12 h-12 mx-auto mb-4 text-neutral-600" />
      <h3 className="font-display text-2xl mb-2">No orders yet</h3>
      <p className="text-neutral-500 mb-6">Orders you place while signed in appear here with their status.</p>
      <Button asChild className="bg-white text-neutral-900 hover:bg-neutral-200 rounded-full h-12 px-6"><Link href="/?view=shop"><ShoppingBag className="w-4 h-4 mr-2" /> Shop the edit</Link></Button>
    </div>
  )
  return (
    <div className="space-y-4" data-testid="orders-list">
      {orders.map(o => (
        <div key={o.id} className="glass rounded-3xl p-6">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <div><div className="text-xs tracking-widest text-neutral-500 uppercase">Order</div><div className="font-medium">{o.id}</div></div>
            <div className="text-sm text-neutral-400">{new Date(o.createdAt).toLocaleString()}</div>
            <Badge className="capitalize bg-emerald-400/15 text-emerald-300 hover:bg-emerald-400/15 border border-emerald-400/20">{o.status}</Badge>
            <div className="font-display text-xl">${Number(o.total || 0).toFixed(2)}</div>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-1">
            {(o.items || []).map((it, i) => (
              <div key={i} className="flex gap-3 items-center min-w-[220px] bg-white/5 rounded-2xl p-2">
                <img src={it.image} alt="" className="w-12 h-14 rounded-xl object-cover" />
                <div className="min-w-0"><div className="text-sm truncate">{it.name}</div><div className="text-xs text-neutral-500">Size {it.size} · ×{it.qty}</div></div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}

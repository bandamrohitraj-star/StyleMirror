import './globals.css'
import { Toaster } from '@/components/ui/sonner'
import { AuthProvider } from '@/components/auth-context'
import { FashionAssistant } from '@/components/fashion-assistant'

export const metadata = {
  title: 'STYLE MIRROR — AI Virtual Try-On Menswear',
  description: 'Premium menswear, reimagined. Try clothes on with AI before you buy, with Mirror, your personal AI stylist.',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="dark">
      <body className="antialiased bg-neutral-950 text-neutral-100">
        <AuthProvider>
          {children}
          <FashionAssistant />
        </AuthProvider>
        <Toaster theme="dark" position="top-center" />
      </body>
    </html>
  )
}

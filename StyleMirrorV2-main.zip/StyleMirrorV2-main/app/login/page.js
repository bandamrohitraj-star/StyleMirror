'use client'
import React, { useEffect, useState, Suspense } from 'react'
import Link from 'next/link'
import { useRouter, useSearchParams } from 'next/navigation'
import { motion } from 'framer-motion'
import { toast } from 'sonner'
import { Sparkles, Mail, Lock, ArrowRight, Loader2, ShoppingBag, Store, Shield } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { useAuth, ROLE_HOME } from '@/components/auth-context'
import { SiteHeader } from '@/components/site-header'
import { LIFESTYLE_IMAGE } from '@/lib/products'

const inputCls = 'h-12 pl-11 bg-white/5 border-white/10 rounded-2xl text-neutral-100 placeholder:text-neutral-600 focus-visible:ring-amber-200/40'

function LoginForm() {
  const { user, loading, login } = useAuth()
  const router = useRouter()
  const sp = useSearchParams()
  const next = sp.get('next')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => { if (!loading && user) router.replace(next || ROLE_HOME[user.role] || '/') }, [user, loading, router, next])

  const submit = async (e) => {
    e.preventDefault()
    setBusy(true)
    try {
      const u = await login(email, password)
      toast.success(`Welcome back, ${u.name.split(' ')[0]}`, { description: `Signed in as ${u.role}` })
      router.replace(next || ROLE_HOME[u.role] || '/')
    } catch (err) { toast.error(err.message) } finally { setBusy(false) }
  }

  return (
    <form onSubmit={submit} className="space-y-5" data-testid="login-form">
      <div className="space-y-2">
        <Label htmlFor="email" className="text-xs tracking-widest text-neutral-500 uppercase">Email</Label>
        <div className="relative"><Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" /><Input id="email" type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" className={inputCls} data-testid="login-email" /></div>
      </div>
      <div className="space-y-2">
        <Label htmlFor="password" className="text-xs tracking-widest text-neutral-500 uppercase">Password</Label>
        <div className="relative"><Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" /><Input id="password" type="password" required value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" className={inputCls} data-testid="login-password" /></div>
      </div>
      <Button type="submit" disabled={busy} className="w-full h-12 rounded-full bg-white text-neutral-900 hover:bg-neutral-200 font-medium" data-testid="login-submit">
        {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}{busy ? 'Signing in…' : 'Sign in'}{!busy && <ArrowRight className="w-4 h-4 ml-2" />}
      </Button>
      <p className="text-sm text-neutral-500 text-center">New here? <Link href="/register" className="text-white hover:text-amber-200 underline-offset-4 hover:underline">Create an account</Link></p>
    </form>
  )
}

export default function LoginPage() {
  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100">
      <SiteHeader />
      <div className="min-h-screen grid lg:grid-cols-2">
        <div className="relative hidden lg:block overflow-hidden">
          <img src={LIFESTYLE_IMAGE} alt="" className="absolute inset-0 w-full h-full object-cover opacity-70" />
          <div className="absolute inset-0 bg-gradient-to-r from-neutral-950/30 via-neutral-950/40 to-neutral-950" />
          <div className="absolute inset-0 gradient-mesh opacity-70" />
          <div className="relative h-full flex flex-col justify-end p-16">
            <Badge className="mb-6 w-fit bg-white/10 border border-white/20 text-white hover:bg-white/10"><Sparkles className="w-3 h-3 mr-1.5" /> Members see more</Badge>
            <h2 className="font-display text-5xl xl:text-6xl leading-[1] mb-6">Your wardrobe, <span className="italic gradient-text">remembered</span>.</h2>
            <div className="grid grid-cols-3 gap-4 max-w-xl">
              {[[ShoppingBag, 'Buyers', 'Saved try-ons & orders'], [Store, 'Sellers', 'List try-on ready pieces'], [Shield, 'Admins', 'Curate the whole store']].map(([I, t, d]) => (
                <div key={t} className="glass rounded-2xl p-4"><I className="w-5 h-5 text-amber-100 mb-2" /><div className="text-sm font-medium">{t}</div><div className="text-xs text-neutral-400">{d}</div></div>
              ))}
            </div>
          </div>
        </div>
        <div className="flex items-center justify-center px-6 pt-32 pb-20 lg:pt-20">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="w-full max-w-md">
            <div className="glass rounded-3xl p-8 md:p-10">
              <div className="text-xs tracking-widest text-neutral-500 uppercase mb-2">Welcome back</div>
              <h1 className="font-display text-4xl md:text-5xl mb-2">Sign in</h1>
              <p className="text-neutral-400 text-sm mb-8">We route you to the right place: buyer, seller or admin.</p>
              <Suspense fallback={null}><LoginForm /></Suspense>
            </div>
            <div className="mt-6 glass rounded-2xl p-4 text-xs text-neutral-500 leading-relaxed">
              <span className="text-neutral-300 font-medium">Demo admin:</span> admin@stylemirror.com · Admin@123
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}

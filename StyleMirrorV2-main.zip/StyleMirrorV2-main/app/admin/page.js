'use client'
import React, { useCallback, useEffect, useState } from 'react'
import { toast } from 'sonner'
import { Users, Package, ShoppingBag, Wand2, DollarSign, Shield, Ban, CheckCircle2, XCircle, Trash2, LayoutDashboard, Search, Store, Clock } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useAuth } from '@/components/auth-context'
import { DashboardShell, StatCard } from '@/components/dashboard-shell'
import { StatusBadge } from '@/components/product-dialog'

const cn = (...c) => c.filter(Boolean).join(' ')
const j = (p, o) => fetch(p, { cache: 'no-store', headers: { 'Content-Type': 'application/json' }, ...o }).then(async r => { const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || 'Request failed'); return d })

export default function AdminPage() {
  const { user } = useAuth()
  const [tab, setTab] = useState('overview')
  const [stats, setStats] = useState(null)
  const [users, setUsers] = useState(null)
  const [products, setProducts] = useState(null)
  const [orders, setOrders] = useState(null)

  const load = useCallback(async () => {
    if (!user || user.role !== 'admin') return
    const [s, u, p, o] = await Promise.all([j('/api/admin/stats'), j('/api/admin/users'), j('/api/admin/products'), j('/api/admin/orders')].map(x => x.catch(() => ({}))))
    setStats(s.stats || null); setUsers(u.users || []); setProducts(p.products || []); setOrders(o.orders || [])
  }, [user])
  useEffect(() => { load() }, [load])

  const tabs = [
    { key: 'overview', label: 'Overview', icon: LayoutDashboard },
    { key: 'users', label: 'Users', icon: Users, count: users?.length },
    { key: 'products', label: 'Products', icon: Package, count: products?.filter(p => p.status === 'pending').length || undefined },
    { key: 'orders', label: 'Orders', icon: ShoppingBag, count: orders?.length },
  ]

  return (
    <DashboardShell allow={['admin']} eyebrow="Admin" title="Control room" subtitle="Curate the catalog, manage the community and keep an eye on the numbers." tabs={tabs} active={tab} onTabChange={setTab}
      aside={<Badge className="bg-gradient-to-r from-amber-200 to-violet-300 text-neutral-900 hover:opacity-90 h-8 px-3"><Shield className="w-3.5 h-3.5 mr-1.5" /> Administrator</Badge>}>
      {tab === 'overview' && <Overview stats={stats} products={products} onReview={() => setTab('products')} />}
      {tab === 'users' && <UsersTab users={users} me={user} reload={load} />}
      {tab === 'products' && <ProductsTab products={products} reload={load} />}
      {tab === 'orders' && <OrdersTab orders={orders} />}
    </DashboardShell>
  )
}

function Overview({ stats, products, onReview }) {
  if (!stats) return <div className="grid md:grid-cols-4 gap-4">{Array(8).fill(0).map((_, i) => <Skeleton key={i} className="h-32 rounded-3xl bg-white/5" />)}</div>
  const pending = (products || []).filter(p => p.status === 'pending')
  return (
    <div className="space-y-8" data-testid="admin-overview">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard icon={Users} label="Users" value={stats.users} hint={`${stats.buyers} buyers · ${stats.sellers} sellers · ${stats.banned} banned`} />
        <StatCard icon={Package} label="Products" value={stats.products} hint={`${stats.pendingProducts} awaiting review`} />
        <StatCard icon={ShoppingBag} label="Orders" value={stats.orders} />
        <StatCard icon={DollarSign} label="Revenue" value={`$${Number(stats.revenue || 0).toLocaleString()}`} />
        <StatCard icon={Wand2} label="AI try-ons generated" value={stats.tryons} />
      </div>
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="glass rounded-3xl p-6">
          <div className="flex items-center justify-between mb-4"><h3 className="font-display text-2xl">Awaiting approval</h3>{pending.length > 0 && <Button variant="ghost" onClick={onReview} className="text-neutral-300 hover:text-white hover:bg-white/5 rounded-full">Review all</Button>}</div>
          {pending.length === 0 ? <p className="text-sm text-neutral-500">Queue is clear. Nothing pending.</p> : (
            <div className="space-y-3">{pending.slice(0, 5).map(p => (
              <div key={p.id} className="flex items-center gap-3"><img src={p.image} alt="" className="w-10 h-12 rounded-lg object-cover" /><div className="min-w-0 flex-1"><div className="text-sm truncate">{p.name}</div><div className="text-xs text-neutral-500">by {p.sellerName} · ${p.price}</div></div><StatusBadge status={p.status} /></div>
            ))}</div>
          )}
        </div>
        <div className="glass rounded-3xl p-6">
          <h3 className="font-display text-2xl mb-4">Recent orders</h3>
          {(stats.recentOrders || []).length === 0 ? <p className="text-sm text-neutral-500">No orders yet.</p> : (
            <div className="space-y-3">{stats.recentOrders.map(o => (
              <div key={o.id} className="flex items-center justify-between text-sm"><div><div className="font-medium">{o.id}</div><div className="text-xs text-neutral-500">{o.userEmail || 'guest'} · {(o.items || []).length} items</div></div><div className="font-display">${Number(o.total || 0).toFixed(2)}</div></div>
            ))}</div>
          )}
        </div>
      </div>
    </div>
  )
}

function UsersTab({ users, me, reload }) {
  const [q, setQ] = useState('')
  if (!users) return <Skeleton className="h-64 rounded-3xl bg-white/5" />
  const list = users.filter(u => !q || u.name?.toLowerCase().includes(q.toLowerCase()) || u.email?.toLowerCase().includes(q.toLowerCase()))
  const patch = async (id, body, msg) => { try { await j(`/api/admin/users/${id}`, { method: 'PATCH', body: JSON.stringify(body) }); toast.success(msg); reload() } catch (e) { toast.error(e.message) } }
  const del = async (u) => { if (!confirm(`Delete ${u.email}? This cannot be undone.`)) return; try { await j(`/api/admin/users/${u.id}`, { method: 'DELETE' }); toast.success('User deleted'); reload() } catch (e) { toast.error(e.message) } }
  return (
    <div className="glass rounded-3xl overflow-hidden" data-testid="admin-users">
      <div className="p-4 border-b border-white/10 flex items-center gap-3"><Search className="w-4 h-4 text-neutral-500" /><Input value={q} onChange={e => setQ(e.target.value)} placeholder="Search by name or email" className="bg-transparent border-0 focus-visible:ring-0 px-0" data-testid="users-search" /></div>
      <Table>
        <TableHeader><TableRow className="border-white/10 hover:bg-transparent"><TableHead className="text-neutral-500">User</TableHead><TableHead className="text-neutral-500">Role</TableHead><TableHead className="text-neutral-500">Status</TableHead><TableHead className="text-neutral-500">Joined</TableHead><TableHead className="text-right text-neutral-500">Actions</TableHead></TableRow></TableHeader>
        <TableBody>
          {list.map(u => {
            const self = u.id === me?.id
            return (
              <TableRow key={u.id} className="border-white/5 hover:bg-white/[0.03]" data-testid={`user-row-${u.email}`}>
                <TableCell><div className="flex items-center gap-3"><div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-200 to-violet-300 text-neutral-900 text-xs font-semibold flex items-center justify-center">{(u.name || '?')[0].toUpperCase()}</div><div><div className="text-sm font-medium">{u.name}{self && <span className="text-neutral-500"> (you)</span>}</div><div className="text-xs text-neutral-500">{u.email}</div></div></div></TableCell>
                <TableCell>
                  <Select value={u.role} disabled={self} onValueChange={v => patch(u.id, { role: v }, `Role changed to ${v}`)}>
                    <SelectTrigger className="h-8 w-[120px] bg-white/5 border-white/10 rounded-full text-xs capitalize" data-testid={`role-select-${u.email}`}><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-neutral-900 border-white/10 text-neutral-100">{['buyer', 'seller', 'admin'].map(r => <SelectItem key={r} value={r} className="capitalize focus:bg-white/10 focus:text-white">{r}</SelectItem>)}</SelectContent>
                  </Select>
                </TableCell>
                <TableCell>{u.banned ? <Badge className="bg-rose-400/15 text-rose-300 border border-rose-400/20 hover:bg-rose-400/15"><Ban className="w-3 h-3 mr-1" />Banned</Badge> : <Badge className="bg-emerald-400/15 text-emerald-300 border border-emerald-400/20 hover:bg-emerald-400/15"><CheckCircle2 className="w-3 h-3 mr-1" />Active</Badge>}</TableCell>
                <TableCell className="text-xs text-neutral-500">{new Date(u.createdAt).toLocaleDateString()}</TableCell>
                <TableCell className="text-right">
                  <div className="inline-flex gap-1">
                    <Button size="sm" variant="outline" disabled={self} onClick={() => patch(u.id, { banned: !u.banned }, u.banned ? 'User unbanned' : 'User banned')} className={cn('rounded-full h-8 text-xs border-white/15 bg-transparent hover:bg-white/5', u.banned && 'text-emerald-300')} data-testid={`ban-${u.email}`}>{u.banned ? 'Unban' : 'Ban'}</Button>
                    <Button size="sm" variant="ghost" disabled={self} onClick={() => del(u)} className="rounded-full h-8 w-8 p-0 text-neutral-400 hover:text-rose-300 hover:bg-rose-500/10" aria-label="Delete user"><Trash2 className="w-3.5 h-3.5" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            )
          })}
        </TableBody>
      </Table>
    </div>
  )
}

function ProductsTab({ products, reload }) {
  const [filter, setFilter] = useState('all')
  if (!products) return <Skeleton className="h-64 rounded-3xl bg-white/5" />
  const list = products.filter(p => filter === 'all' || p.status === filter)
  const setStatus = async (p, status) => { try { await j(`/api/admin/products/${p.id}`, { method: 'PATCH', body: JSON.stringify({ status }) }); toast.success(status === 'approved' ? 'Product approved' : status === 'rejected' ? 'Product rejected' : 'Status updated'); reload() } catch (e) { toast.error(e.message) } }
  const del = async (p) => { if (!confirm(`Remove "${p.name}" from the store?`)) return; try { await j(`/api/admin/products/${p.id}`, { method: 'DELETE' }); toast.success('Product removed'); reload() } catch (e) { toast.error(e.message) } }
  return (
    <div className="space-y-4" data-testid="admin-products">
      <div className="flex gap-1 flex-wrap">
        {[['all', 'All', products.length], ['pending', 'Pending', products.filter(p => p.status === 'pending').length], ['approved', 'Live', products.filter(p => p.status === 'approved').length], ['rejected', 'Rejected', products.filter(p => p.status === 'rejected').length]].map(([k, l, n]) => (
          <button key={k} onClick={() => setFilter(k)} className={cn('h-9 px-4 rounded-full text-xs font-medium transition inline-flex items-center gap-1.5', filter === k ? 'bg-white text-neutral-900' : 'bg-white/5 text-neutral-300 hover:bg-white/10')} data-testid={`filter-${k}`}>{l}<span className="opacity-60">{n}</span></button>
        ))}
      </div>
      <div className="glass rounded-3xl overflow-hidden">
        <Table>
          <TableHeader><TableRow className="border-white/10 hover:bg-transparent"><TableHead className="text-neutral-500">Product</TableHead><TableHead className="text-neutral-500">Seller</TableHead><TableHead className="text-neutral-500">Price</TableHead><TableHead className="text-neutral-500">Status</TableHead><TableHead className="text-right text-neutral-500">Actions</TableHead></TableRow></TableHeader>
          <TableBody>
            {list.length === 0 && <TableRow><TableCell colSpan={5} className="text-center text-neutral-500 py-10">Nothing here.</TableCell></TableRow>}
            {list.map(p => (
              <TableRow key={p.id} className="border-white/5 hover:bg-white/[0.03]" data-testid={`product-row-${p.id}`}>
                <TableCell><div className="flex items-center gap-3"><img src={p.image} alt="" className="w-10 h-12 rounded-lg object-cover" /><div className="min-w-0"><div className="text-sm font-medium truncate max-w-[220px]">{p.name}</div><div className="text-xs text-neutral-500">{p.category} · {p.brand}</div></div></div></TableCell>
                <TableCell className="text-sm text-neutral-300"><div className="inline-flex items-center gap-1.5"><Store className="w-3.5 h-3.5 text-neutral-500" />{p.sellerName || 'House'}</div></TableCell>
                <TableCell className="text-sm">${p.price}</TableCell>
                <TableCell><StatusBadge status={p.status} /></TableCell>
                <TableCell className="text-right">
                  <div className="inline-flex gap-1">
                    {p.status !== 'approved' && <Button size="sm" onClick={() => setStatus(p, 'approved')} className="rounded-full h-8 text-xs bg-emerald-400/15 text-emerald-300 hover:bg-emerald-400/25 border border-emerald-400/20" data-testid={`approve-${p.id}`}><CheckCircle2 className="w-3.5 h-3.5 mr-1" />Approve</Button>}
                    {p.status !== 'rejected' && <Button size="sm" variant="outline" onClick={() => setStatus(p, 'rejected')} className="rounded-full h-8 text-xs border-white/15 bg-transparent hover:bg-white/5" data-testid={`reject-${p.id}`}><XCircle className="w-3.5 h-3.5 mr-1" />Reject</Button>}
                    {p.status === 'approved' && <Button size="sm" variant="outline" onClick={() => setStatus(p, 'pending')} className="rounded-full h-8 text-xs border-white/15 bg-transparent hover:bg-white/5"><Clock className="w-3.5 h-3.5 mr-1" />Unpublish</Button>}
                    <Button size="sm" variant="ghost" onClick={() => del(p)} className="rounded-full h-8 w-8 p-0 text-neutral-400 hover:text-rose-300 hover:bg-rose-500/10" aria-label="Remove product" data-testid={`remove-${p.id}`}><Trash2 className="w-3.5 h-3.5" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

function OrdersTab({ orders }) {
  if (!orders) return <Skeleton className="h-64 rounded-3xl bg-white/5" />
  return (
    <div className="glass rounded-3xl overflow-hidden" data-testid="admin-orders">
      <Table>
        <TableHeader><TableRow className="border-white/10 hover:bg-transparent"><TableHead className="text-neutral-500">Order</TableHead><TableHead className="text-neutral-500">Customer</TableHead><TableHead className="text-neutral-500">Items</TableHead><TableHead className="text-neutral-500">Total</TableHead><TableHead className="text-neutral-500">Status</TableHead><TableHead className="text-neutral-500">Date</TableHead></TableRow></TableHeader>
        <TableBody>
          {orders.length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-neutral-500 py-10">No orders yet.</TableCell></TableRow>}
          {orders.map(o => (
            <TableRow key={o.id} className="border-white/5 hover:bg-white/[0.03]">
              <TableCell className="text-sm font-medium">{o.id}</TableCell>
              <TableCell className="text-sm text-neutral-300">{o.userEmail || 'Guest'}</TableCell>
              <TableCell><div className="flex -space-x-2">{(o.items || []).slice(0, 4).map((it, i) => <img key={i} src={it.image} alt="" className="w-8 h-10 rounded-md object-cover ring-2 ring-neutral-950" />)}{(o.items || []).length > 4 && <div className="w-8 h-10 rounded-md bg-white/10 text-[10px] flex items-center justify-center ring-2 ring-neutral-950">+{o.items.length - 4}</div>}</div></TableCell>
              <TableCell className="text-sm">${Number(o.total || 0).toFixed(2)}</TableCell>
              <TableCell><Badge className="capitalize bg-emerald-400/15 text-emerald-300 border border-emerald-400/20 hover:bg-emerald-400/15">{o.status}</Badge></TableCell>
              <TableCell className="text-xs text-neutral-500">{new Date(o.createdAt).toLocaleString()}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

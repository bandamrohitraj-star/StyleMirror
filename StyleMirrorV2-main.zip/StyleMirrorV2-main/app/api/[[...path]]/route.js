import { NextResponse } from 'next/server'
import { v4 as uuidv4 } from 'uuid'
import bcrypt from 'bcryptjs'
import { getDb } from '@/lib/db'
import { PRODUCTS } from '@/lib/products'
import { AUTH_COOKIE, signToken, verifyToken, sanitizeUser } from '@/lib/auth'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 60

const GATEWAY = 'https://integrations.emergentagent.com/llm/v1/chat/completions'
// Models (per Emergent integration playbook) with safe fallbacks
const MODEL_IMAGE_GEN = 'gemini/gemini-3.1-flash-image-preview'
// NOTE: gateway currently rejects gemini-3.8-flash / 3.5-flash-lite ("Invalid model name"), so the verified
// gemini-2.5-flash is first and the playbook names are kept as fallbacks for when they go live.
const MODELS_VISION = ['gemini/gemini-2.5-flash', 'gemini/gemini-3.8-flash']
const MODELS_CHAT = ['gemini/gemini-2.5-flash', 'gemini/gemini-3.5-flash-lite']

const ADMIN_EMAIL = 'admin@stylemirror.com'
const ADMIN_PASSWORD = 'Admin@123'

// ---------- Response helpers ----------
function ok(data, status = 200) { return NextResponse.json(data, { status }) }
function bad(error, status = 400) { return NextResponse.json({ error }, { status }) }

// ---------- Seed ----------
let seeded = false
async function ensureSeed(db) {
  if (seeded) return
  const admin = await db.collection('users').findOne({ email: ADMIN_EMAIL })
  if (!admin) {
    await db.collection('users').insertOne({
      id: uuidv4(), name: 'Mirror Admin', email: ADMIN_EMAIL,
      passwordHash: await bcrypt.hash(ADMIN_PASSWORD, 10),
      role: 'admin', banned: false, createdAt: new Date().toISOString()
    })
  }
  const count = await db.collection('products').countDocuments()
  if (count === 0) {
    const now = new Date().toISOString()
    await db.collection('products').insertMany(PRODUCTS.map(p => ({
      ...p, status: 'approved', sellerId: null, sellerName: 'STYLE MIRROR', createdAt: now, updatedAt: now
    })))
  }
  seeded = true
}

// ---------- Auth helpers ----------
async function getUser(req, db) {
  const token = req.cookies.get(AUTH_COOKIE)?.value
  if (!token) return null
  const payload = await verifyToken(token)
  if (!payload?.sub) return null
  const u = await db.collection('users').findOne({ id: payload.sub })
  if (!u || u.banned) return null
  return u
}
function setAuthCookie(res, token) {
  res.cookies.set(AUTH_COOKIE, token, {
    httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production',
    path: '/', maxAge: 60 * 60 * 24 * 7
  })
  return res
}
function requireRole(user, roles) {
  if (!user) return bad('Authentication required', 401)
  if (!roles.includes(user.role)) return bad('Forbidden', 403)
  return null
}
const strip = (doc) => { if (!doc) return doc; const { _id, ...rest } = doc; return rest }

// ---------- AI: shared gateway call with model fallback ----------
async function gatewayChat({ models, messages, modalities, temperature = 0.4 }) {
  const key = process.env.EMERGENT_LLM_KEY
  if (!key) throw new Error('EMERGENT_LLM_KEY missing')
  let lastErr = null
  for (const model of models) {
    const body = { model, messages, temperature }
    if (modalities) body.modalities = modalities
    const resp = await fetch(GATEWAY, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
      body: JSON.stringify(body), cache: 'no-store'
    })
    const json = await resp.json().catch(() => ({}))
    if (resp.ok) return json
    lastErr = new Error(json?.error?.message || `Gateway error ${resp.status}`)
    const msg = String(lastErr.message).toLowerCase()
    // Try next model only when the model itself is the problem
    if (!(msg.includes('model') || msg.includes('not found') || msg.includes('invalid') || resp.status === 404 || resp.status === 400)) break
    console.warn(`[gateway] model ${model} failed: ${lastErr.message} — trying fallback`)
  }
  throw lastErr || new Error('AI request failed')
}

function extractJson(text) {
  if (!text) throw new Error('Empty AI response')
  const cleaned = String(text).replace(/```json/gi, '```').replace(/```/g, '').trim()
  try { return JSON.parse(cleaned) } catch {}
  const start = cleaned.indexOf('{'); const end = cleaned.lastIndexOf('}')
  if (start >= 0 && end > start) return JSON.parse(cleaned.slice(start, end + 1))
  throw new Error('AI response was not valid JSON')
}
function contentToText(json) {
  const c = json?.choices?.[0]?.message?.content
  if (typeof c === 'string') return c
  if (Array.isArray(c)) return c.map(p => p?.text || '').join('\n')
  return ''
}

// ---------- AI: Virtual try-on (image generation) ----------
async function generateTryOn({ personBase64, personMime, garmentBase64, garmentMime, extraPrompt }) {
  const instruction = [
    'You are a professional virtual try-on stylist. Create a photorealistic image where the PERSON in Image 1 is wearing the GARMENT shown in Image 2.',
    "Preserve the person's face, identity, pose, body proportions, skin tone, hair, hands, and background exactly.",
    "Preserve the garment's exact color, pattern, texture, logo/print placement, neckline, sleeves, seams, buttons and silhouette.",
    'Fit the garment naturally on the body with realistic drape, folds, shadows, and consistent lighting from the person photo.',
    'Do not add accessories, do not change camera angle, do not beautify the person, do not modify the garment design.',
    extraPrompt || '',
    'Return the edited photo as an image.'
  ].filter(Boolean).join(' ')

  const json = await gatewayChat({
    models: [MODEL_IMAGE_GEN],
    modalities: ['image', 'text'],
    messages: [{
      role: 'user',
      content: [
        { type: 'text', text: instruction },
        { type: 'image_url', image_url: { url: `data:${personMime};base64,${personBase64}` } },
        { type: 'image_url', image_url: { url: `data:${garmentMime};base64,${garmentBase64}` } },
      ]
    }]
  })

  const msg = json?.choices?.[0]?.message || {}
  if (Array.isArray(msg.images) && msg.images.length) {
    const first = msg.images[0]
    if (typeof first === 'string') return { dataUrl: first.startsWith('data:') ? first : `data:image/png;base64,${first}` }
    if (first?.image_url?.url) return { dataUrl: first.image_url.url }
    if (first?.b64_json) return { dataUrl: `data:image/png;base64,${first.b64_json}` }
  }
  if (Array.isArray(msg.content)) {
    for (const part of msg.content) {
      if (part?.type === 'image_url' && part?.image_url?.url) return { dataUrl: part.image_url.url }
      if (part?.type === 'image' && (part?.image?.b64_json || part?.image?.url)) return { dataUrl: part.image.url || `data:image/png;base64,${part.image.b64_json}` }
    }
  }
  if (typeof msg.content === 'string') {
    const md = msg.content.match(/data:image\/[a-zA-Z0-9.+-]+;base64,[A-Za-z0-9+/=]+/)
    if (md) return { dataUrl: md[0] }
    const mdUrl = msg.content.match(/!\[[^\]]*\]\(([^)]+)\)/)
    if (mdUrl) return { dataUrl: mdUrl[1] }
  }
  if (json?.data?.[0]?.b64_json) return { dataUrl: `data:image/png;base64,${json.data[0].b64_json}` }
  if (json?.data?.[0]?.url) return { dataUrl: json.data[0].url }
  console.error('No image found in AI response:', JSON.stringify(json).slice(0, 800))
  throw new Error('The AI did not return an image. Try a clearer photo or different garment.')
}

// ---------- AI: Fashion Assist ----------
const catalogSummary = (products) => products.map(p =>
  `${p.id} | ${p.name} | ${p.category} | $${p.price} | colors: ${(p.colors || []).join('/')} | tags: ${(p.tags || []).join(',')}`
).join('\n')

async function analyzeLook({ base64, mime, products, occasion }) {
  const prompt = `You are "Mirror", a friendly male personal stylist for STYLE MIRROR, a premium men's fashion store.
Analyze this photo ONLY for fashion assistance. Do not identify the person. Do not make attractiveness judgments.
Estimate (with uncertainty): approximate visible skin tone category + undertone (warm/cool/neutral), broad body silhouette for clothing fit (e.g. slim, athletic, average, broad), current style vibe, and the best colour palette for them.
${occasion ? `The customer is dressing for: ${occasion}.` : ''}
Then recommend 3 to 5 products from this catalog (use exact ids) that would suit them best, with a short reason each.

CATALOG:
${catalogSummary(products)}

Return ONLY a JSON object with this exact shape:
{
  "skin_tone": {"category": string, "undertone": string, "confidence": number},
  "body_type": {"category": string, "confidence": number},
  "style_vibe": string,
  "palette": [string],
  "spoken_summary": string,
  "tips": [string],
  "recommendations": [{"productId": string, "reason": string}],
  "limitations": [string]
}
"spoken_summary" must be 2 short friendly sentences spoken out loud by Mirror (first person, warm, confident, no lists). "tips" = 3 concise styling tips. Say "unknown" where the photo does not support an inference.`

  const json = await gatewayChat({
    models: MODELS_VISION, temperature: 0.3,
    messages: [{ role: 'user', content: [
      { type: 'text', text: prompt },
      { type: 'image_url', image_url: { url: `data:${mime};base64,${base64}` } },
    ] }]
  })
  const parsed = extractJson(contentToText(json))
  const valid = (Array.isArray(parsed.recommendations) ? parsed.recommendations : [])
    .filter(r => products.find(p => p.id === r.productId)).slice(0, 5)
  if (valid.length === 0) {
    // guarantee at least some recommendations
    valid.push(...products.slice(0, 3).map(p => ({ productId: p.id, reason: 'A versatile staple that works for most wardrobes.' })))
  }
  return {
    skin_tone: parsed.skin_tone || { category: 'unknown', undertone: 'unknown', confidence: 0 },
    body_type: parsed.body_type || { category: 'unknown', confidence: 0 },
    style_vibe: parsed.style_vibe || 'Modern casual',
    palette: Array.isArray(parsed.palette) ? parsed.palette.slice(0, 6) : [],
    spoken_summary: parsed.spoken_summary || "I've looked at your photo and picked a few pieces I think you'll love.",
    tips: Array.isArray(parsed.tips) ? parsed.tips.slice(0, 4) : [],
    limitations: Array.isArray(parsed.limitations) ? parsed.limitations.slice(0, 3) : [],
    recommendations: valid.map(r => ({ ...r, product: products.find(p => p.id === r.productId) })),
  }
}

async function stylistChat({ message, history, context, products }) {
  const system = `You are "Mirror", the friendly male AI stylist living on STYLE MIRROR, a premium men's fashion website with an AI virtual try-on studio.
Keep answers short (max 3 sentences) because they are spoken out loud. Be warm, confident, practical. Never infer sensitive traits.
You can recommend products from the catalog by id. Current page context: ${JSON.stringify(context || {})}.
CATALOG:
${catalogSummary(products)}

Always respond with ONLY a JSON object: {"reply": string, "productIds": [string]} where productIds are 0-4 catalog ids you mention or recommend.`
  const safeHistory = (Array.isArray(history) ? history : [])
    .filter(m => ['user', 'assistant'].includes(m?.role) && typeof m?.content === 'string')
    .slice(-10).map(m => ({ role: m.role, content: m.content.slice(0, 2000) }))
  const json = await gatewayChat({
    models: MODELS_CHAT, temperature: 0.6,
    messages: [{ role: 'system', content: system }, ...safeHistory, { role: 'user', content: message }]
  })
  const text = contentToText(json)
  let parsed
  try { parsed = extractJson(text) } catch { parsed = { reply: text.slice(0, 600), productIds: [] } }
  const ids = (Array.isArray(parsed.productIds) ? parsed.productIds : []).filter(id => products.find(p => p.id === id)).slice(0, 4)
  return { reply: String(parsed.reply || text).trim(), products: ids.map(id => products.find(p => p.id === id)) }
}

// ---------- Image helpers ----------
async function imageToBase64(url) {
  if (url.startsWith('data:')) {
    const m = url.match(/^data:([^;]+);base64,(.+)$/)
    if (!m) throw new Error('Invalid data URL')
    return { mime: m[1], base64: m[2] }
  }
  const r = await fetch(url)
  if (!r.ok) throw new Error('Failed to fetch garment image')
  const ct = r.headers.get('content-type') || 'image/jpeg'
  const buf = Buffer.from(await r.arrayBuffer())
  return { mime: ct, base64: buf.toString('base64') }
}

const sanitizeProductInput = (b) => ({
  name: String(b.name || '').trim().slice(0, 120),
  price: Math.max(0, Number(b.price) || 0),
  category: String(b.category || 'Other').trim().slice(0, 60),
  brand: String(b.brand || '').trim().slice(0, 60),
  colors: Array.isArray(b.colors) ? b.colors.map(String).slice(0, 10) : String(b.colors || '').split(',').map(s => s.trim()).filter(Boolean).slice(0, 10),
  sizes: Array.isArray(b.sizes) ? b.sizes.map(String).slice(0, 12) : String(b.sizes || '').split(',').map(s => s.trim()).filter(Boolean).slice(0, 12),
  image: String(b.image || ''),
  description: String(b.description || '').trim().slice(0, 1200),
  tags: Array.isArray(b.tags) ? b.tags.map(String).slice(0, 6) : String(b.tags || '').split(',').map(s => s.trim()).filter(Boolean).slice(0, 6),
})

// ---------- Routing ----------
async function handleRoute(req, path, method) {
  const [root, second, third] = path
  const db = await getDb()
  await ensureSeed(db)

  if (!root) return ok({ name: 'STYLE MIRROR API', status: 'ok', time: new Date().toISOString() })

  // ===== AUTH =====
  if (root === 'auth') {
    if (second === 'register' && method === 'POST') {
      const body = await req.json().catch(() => ({}))
      const name = String(body.name || '').trim()
      const email = String(body.email || '').trim().toLowerCase()
      const password = String(body.password || '')
      if (!name || !email || !password) return bad('Name, email and password are required')
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return bad('Invalid email address')
      if (password.length < 6) return bad('Password must be at least 6 characters')
      const exists = await db.collection('users').findOne({ email })
      if (exists) return bad('An account with this email already exists', 409)
      const user = {
        id: uuidv4(), name, email, passwordHash: await bcrypt.hash(password, 10),
        role: body.wantsSeller ? 'seller' : 'buyer', banned: false,
        phone: '', address: '', createdAt: new Date().toISOString()
      }
      await db.collection('users').insertOne(user)
      const token = await signToken({ sub: user.id, role: user.role })
      return setAuthCookie(ok({ user: sanitizeUser(user), token }, 201), token)
    }
    if (second === 'login' && method === 'POST') {
      const body = await req.json().catch(() => ({}))
      const email = String(body.email || '').trim().toLowerCase()
      const password = String(body.password || '')
      const user = await db.collection('users').findOne({ email })
      if (!user || !(await bcrypt.compare(password, user.passwordHash))) return bad('Invalid email or password', 401)
      if (user.banned) return bad('This account has been suspended. Contact support.', 403)
      const token = await signToken({ sub: user.id, role: user.role })
      return setAuthCookie(ok({ user: sanitizeUser(user), token }), token)
    }
    if (second === 'logout' && method === 'POST') {
      const res = ok({ loggedOut: true })
      res.cookies.set(AUTH_COOKIE, '', { httpOnly: true, path: '/', maxAge: 0 })
      return res
    }
    if (second === 'me' && method === 'GET') {
      const user = await getUser(req, db)
      return ok({ user: sanitizeUser(user) })
    }
  }

  // ===== ME (any logged-in user) =====
  if (root === 'me') {
    const user = await getUser(req, db)
    const denied = requireRole(user, ['buyer', 'seller', 'admin']); if (denied) return denied
    if (!second && method === 'PATCH') {
      const body = await req.json().catch(() => ({}))
      const update = {}
      for (const k of ['name', 'phone', 'address', 'avatar']) if (body[k] !== undefined) update[k] = String(body[k]).slice(0, 400)
      if (body.newPassword) {
        if (!body.currentPassword || !(await bcrypt.compare(String(body.currentPassword), user.passwordHash))) return bad('Current password is incorrect')
        if (String(body.newPassword).length < 6) return bad('New password must be at least 6 characters')
        update.passwordHash = await bcrypt.hash(String(body.newPassword), 10)
      }
      await db.collection('users').updateOne({ id: user.id }, { $set: update })
      const fresh = await db.collection('users').findOne({ id: user.id })
      return ok({ user: sanitizeUser(fresh) })
    }
    if (second === 'tryons' && method === 'GET') {
      const items = await db.collection('tryOnHistory').find({ userId: user.id }).sort({ createdAt: -1 }).limit(40).toArray()
      return ok({ tryons: items.map(strip) })
    }
    if (second === 'orders' && method === 'GET') {
      const items = await db.collection('orders').find({ userId: user.id }).sort({ createdAt: -1 }).limit(50).toArray()
      return ok({ orders: items.map(strip) })
    }
  }

  // ===== PRODUCTS (public, approved only) =====
  if (root === 'products') {
    if (method === 'GET' && !second) {
      const products = await db.collection('products').find({ status: 'approved' }).sort({ createdAt: 1 }).toArray()
      return ok({ products: products.map(strip) })
    }
    if (method === 'GET' && second) {
      const p = await db.collection('products').findOne({ id: second, status: 'approved' })
      return p ? ok({ product: strip(p) }) : bad('Product not found', 404)
    }
  }

  // ===== SELLER =====
  if (root === 'seller') {
    const user = await getUser(req, db)
    const denied = requireRole(user, ['seller', 'admin']); if (denied) return denied
    if (second === 'products') {
      if (method === 'GET' && !third) {
        const items = await db.collection('products').find({ sellerId: user.id }).sort({ createdAt: -1 }).toArray()
        return ok({ products: items.map(strip) })
      }
      if (method === 'POST' && !third) {
        const body = await req.json().catch(() => ({}))
        const data = sanitizeProductInput(body)
        if (!data.name || !data.price || !data.image) return bad('Name, price and image are required')
        if (data.image.length > 2_000_000) return bad('Image too large (max ~1.5MB). Please use a smaller photo.', 413)
        const now = new Date().toISOString()
        const product = { id: uuidv4(), ...data, brand: data.brand || user.name, rating: 0, reviews: 0, status: 'pending', sellerId: user.id, sellerName: user.name, createdAt: now, updatedAt: now }
        await db.collection('products').insertOne(product)
        return ok({ product: strip(product) }, 201)
      }
      if ((method === 'PUT' || method === 'PATCH') && third) {
        const existing = await db.collection('products').findOne({ id: third })
        if (!existing) return bad('Product not found', 404)
        if (existing.sellerId !== user.id && user.role !== 'admin') return bad('Forbidden', 403)
        const body = await req.json().catch(() => ({}))
        const data = sanitizeProductInput({ ...existing, ...body })
        if (data.image.length > 2_000_000) return bad('Image too large (max ~1.5MB).', 413)
        // edits to approved products go back to pending for admin review
        const status = user.role === 'admin' ? existing.status : 'pending'
        await db.collection('products').updateOne({ id: third }, { $set: { ...data, status, updatedAt: new Date().toISOString() } })
        return ok({ product: strip(await db.collection('products').findOne({ id: third })) })
      }
      if (method === 'DELETE' && third) {
        const existing = await db.collection('products').findOne({ id: third })
        if (!existing) return bad('Product not found', 404)
        if (existing.sellerId !== user.id && user.role !== 'admin') return bad('Forbidden', 403)
        await db.collection('products').deleteOne({ id: third })
        return ok({ deleted: true })
      }
    }
    if (second === 'stats' && method === 'GET') {
      const mine = await db.collection('products').find({ sellerId: user.id }).toArray()
      const orders = await db.collection('orders').find({ 'items.id': { $in: mine.map(p => p.id) } }).toArray()
      return ok({ stats: { total: mine.length, approved: mine.filter(p => p.status === 'approved').length, pending: mine.filter(p => p.status === 'pending').length, rejected: mine.filter(p => p.status === 'rejected').length, orders: orders.length } })
    }
  }

  // ===== ADMIN =====
  if (root === 'admin') {
    const user = await getUser(req, db)
    const denied = requireRole(user, ['admin']); if (denied) return denied
    if (second === 'stats' && method === 'GET') {
      const [users, products, orders, tryons] = await Promise.all([
        db.collection('users').find({}).toArray(),
        db.collection('products').find({}).toArray(),
        db.collection('orders').find({}).toArray(),
        db.collection('tryOnHistory').countDocuments(),
      ])
      const revenue = orders.reduce((s, o) => s + (Number(o.total) || 0), 0)
      return ok({ stats: {
        users: users.length, buyers: users.filter(u => u.role === 'buyer').length, sellers: users.filter(u => u.role === 'seller').length,
        banned: users.filter(u => u.banned).length, products: products.length, pendingProducts: products.filter(p => p.status === 'pending').length,
        orders: orders.length, revenue, tryons,
        recentOrders: orders.sort((a, b) => (b.createdAt > a.createdAt ? 1 : -1)).slice(0, 6).map(strip),
      } })
    }
    if (second === 'users') {
      if (method === 'GET' && !third) {
        const items = await db.collection('users').find({}).sort({ createdAt: -1 }).toArray()
        return ok({ users: items.map(sanitizeUser) })
      }
      if (method === 'PATCH' && third) {
        const target = await db.collection('users').findOne({ id: third })
        if (!target) return bad('User not found', 404)
        if (target.id === user.id) return bad('You cannot modify your own account here')
        const body = await req.json().catch(() => ({}))
        const update = {}
        if (body.role && ['buyer', 'seller', 'admin'].includes(body.role)) update.role = body.role
        if (typeof body.banned === 'boolean') update.banned = body.banned
        await db.collection('users').updateOne({ id: third }, { $set: update })
        return ok({ user: sanitizeUser(await db.collection('users').findOne({ id: third })) })
      }
      if (method === 'DELETE' && third) {
        if (third === user.id) return bad('You cannot delete yourself')
        await db.collection('users').deleteOne({ id: third })
        return ok({ deleted: true })
      }
    }
    if (second === 'products') {
      if (method === 'GET' && !third) {
        const items = await db.collection('products').find({}).sort({ createdAt: -1 }).toArray()
        return ok({ products: items.map(strip) })
      }
      if (method === 'PATCH' && third) {
        const body = await req.json().catch(() => ({}))
        const update = { updatedAt: new Date().toISOString() }
        if (body.status && ['approved', 'pending', 'rejected'].includes(body.status)) update.status = body.status
        if (body.tags) update.tags = Array.isArray(body.tags) ? body.tags : []
        const r = await db.collection('products').updateOne({ id: third }, { $set: update })
        if (!r.matchedCount) return bad('Product not found', 404)
        return ok({ product: strip(await db.collection('products').findOne({ id: third })) })
      }
      if (method === 'DELETE' && third) {
        await db.collection('products').deleteOne({ id: third })
        return ok({ deleted: true })
      }
    }
    if (second === 'orders' && method === 'GET') {
      const items = await db.collection('orders').find({}).sort({ createdAt: -1 }).limit(100).toArray()
      return ok({ orders: items.map(strip) })
    }
  }

  // ===== TRY-ON =====
  if (root === 'try-on' && method === 'POST') {
    const user = await getUser(req, db)
    const form = await req.formData()
    const person = form.get('person')
    const productId = form.get('productId')
    const garmentFile = form.get('garment')
    const extraPrompt = form.get('prompt') || ''
    const sessionId = form.get('sessionId') || uuidv4()
    if (!person || typeof person === 'string') return bad('Person image required')

    const personBuf = Buffer.from(await person.arrayBuffer())
    const personBase64 = personBuf.toString('base64')
    const personMime = person.type || 'image/jpeg'

    let garmentBase64, garmentMime, productMeta = null
    if (garmentFile && typeof garmentFile !== 'string') {
      const gb = Buffer.from(await garmentFile.arrayBuffer())
      garmentBase64 = gb.toString('base64'); garmentMime = garmentFile.type || 'image/jpeg'
    } else if (productId) {
      const product = await db.collection('products').findOne({ id: productId })
      if (!product) return bad('Invalid productId', 404)
      const g = await imageToBase64(product.image)
      garmentBase64 = g.base64; garmentMime = g.mime
      productMeta = { id: product.id, name: product.name, image: product.image, price: product.price }
    } else return bad('Provide a productId or a garment file')

    try {
      const { dataUrl } = await generateTryOn({ personBase64, personMime, garmentBase64, garmentMime, extraPrompt })
      const jobId = uuidv4()
      await db.collection('tryOnHistory').insertOne({ id: jobId, sessionId, userId: user?.id || null, product: productMeta, resultDataUrl: dataUrl, createdAt: new Date().toISOString() })
      return ok({ id: jobId, sessionId, resultDataUrl: dataUrl, product: productMeta })
    } catch (e) {
      console.error('try-on failure', e)
      return bad(e.message || 'AI generation failed', 500)
    }
  }

  // ===== HISTORY (session based, legacy) =====
  if (root === 'history' && method === 'GET') {
    const url = new URL(req.url)
    const sessionId = url.searchParams.get('sessionId')
    const user = await getUser(req, db)
    const query = user ? { $or: [{ userId: user.id }, ...(sessionId ? [{ sessionId }] : [])] } : (sessionId ? { sessionId } : null)
    if (!query) return ok({ history: [] })
    const items = await db.collection('tryOnHistory').find(query).sort({ createdAt: -1 }).limit(30).toArray()
    return ok({ history: items.map(strip) })
  }
  if (root === 'history' && method === 'DELETE' && second) {
    await db.collection('tryOnHistory').deleteOne({ id: second })
    return ok({ deleted: true })
  }

  // ===== ORDERS =====
  if (root === 'orders' && method === 'POST') {
    const user = await getUser(req, db)
    const body = await req.json().catch(() => ({}))
    const orderId = 'SM-' + Date.now().toString(36).toUpperCase()
    await db.collection('orders').insertOne({ id: orderId, userId: user?.id || null, userEmail: user?.email || null, ...body, createdAt: new Date().toISOString(), status: 'confirmed' })
    return ok({ orderId, status: 'confirmed' })
  }

  // ===== FASHION ASSIST =====
  if (root === 'assist') {
    if (second === 'analyze' && method === 'POST') {
      const user = await getUser(req, db)
      const form = await req.formData()
      const photo = form.get('photo')
      const occasion = String(form.get('occasion') || '')
      if (!photo || typeof photo === 'string') return bad('photo is required')
      if (!String(photo.type || '').startsWith('image/')) return bad('Only image files are accepted')
      if (photo.size > 8 * 1024 * 1024) return bad('Maximum image size is 8 MB', 413)
      const base64 = Buffer.from(await photo.arrayBuffer()).toString('base64')
      const products = (await db.collection('products').find({ status: 'approved' }).toArray()).map(strip)
      try {
        const analysis = await analyzeLook({ base64, mime: photo.type, products, occasion })
        const id = uuidv4()
        await db.collection('fashionAnalyses').insertOne({ id, userId: user?.id || null, analysis: { ...analysis, recommendations: analysis.recommendations.map(r => ({ productId: r.productId, reason: r.reason })) }, createdAt: new Date().toISOString() })
        return ok({ id, analysis })
      } catch (e) {
        console.error('assist analyze failed', e.message)
        return bad('Unable to analyze the photo right now. Please try another image.', 500)
      }
    }
    if (second === 'chat' && method === 'POST') {
      const body = await req.json().catch(() => ({}))
      const message = String(body.message || '').trim()
      if (!message || message.length > 4000) return bad('A message of 1-4000 characters is required')
      const products = (await db.collection('products').find({ status: 'approved' }).toArray()).map(strip)
      try {
        const result = await stylistChat({ message, history: body.history, context: body.context, products })
        return ok(result)
      } catch (e) {
        console.error('assist chat failed', e.message)
        return bad('Mirror is having trouble answering right now.', 500)
      }
    }
  }

  return bad('Route not found', 404)
}

const wrap = (method) => async (req, { params }) => {
  try { const p = (await params).path || []; return await handleRoute(req, p, method) }
  catch (e) { console.error(`[api ${method}]`, e); return bad(e.message || 'Server error', 500) }
}
export const GET = wrap('GET')
export const POST = wrap('POST')
export const PUT = wrap('PUT')
export const PATCH = wrap('PATCH')
export const DELETE = wrap('DELETE')

'use client'
import React, { useCallback, useEffect, useState } from 'react'
import { toast } from 'sonner'
import { Plus, Package, Pencil, Trash2, Store, CheckCircle2, Clock, XCircle, LayoutGrid } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { useAuth } from '@/components/auth-context'
import { DashboardShell, StatCard } from '@/components/dashboard-shell'
import { ProductDialog, StatusBadge } from '@/components/product-dialog'

export default function SellerPage() {
  const { user } = useAuth()
  const [tab, setTab] = useState('products')
  const [products, setProducts] = useState(null)
  const [stats, setStats] = useState(null)
  const [editing, setEditing] = useState(null) // null | {} (new) | product

  const load = useCallback(async () => {
    if (!user) return
    const [p, s] = await Promise.all([
      fetch('/api/seller/products', { cache: 'no-store' }).then(r => r.json()).catch(() => ({})),
      fetch('/api/seller/stats', { cache: 'no-store' }).then(r => r.json()).catch(() => ({})),
    ])
    setProducts(p.products || []); setStats(s.stats || null)
  }, [user])
  useEffect(() => { load() }, [load])

  const remove = async (p) => {
    if (!confirm(`Delete "${p.name}"?`)) return
    const r = await fetch(`/api/seller/products/${p.id}`, { method: 'DELETE' })
    if (r.ok) { toast.success('Product deleted'); load() } else toast.error('Could not delete')
  }

  return (
    <DashboardShell allow={['seller', 'admin']} eyebrow="Seller console" title={user ? `${user.name.split(' ')[0]}'s atelier` : 'Seller console'} subtitle="List pieces, upload imagery, and watch them go live. Every approved product is instantly AI try-on ready."
      tabs={[{ key: 'products', label: 'My products', icon: LayoutGrid, count: products?.length }]} active={tab} onTabChange={setTab}
      aside={<Button onClick={() => setEditing({})} className="bg-gradient-to-r from-amber-200 to-violet-300 text-neutral-900 hover:opacity-90 rounded-full h-11 px-6 font-medium" data-testid="add-product-btn"><Plus className="w-4 h-4 mr-2" /> Add product</Button>}>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-10">
        <StatCard icon={Package} label="Total listings" value={stats?.total ?? '—'} />
        <StatCard icon={CheckCircle2} label="Live in shop" value={stats?.approved ?? '—'} />
        <StatCard icon={Clock} label="Pending review" value={stats?.pending ?? '—'} />
        <StatCard icon={XCircle} label="Rejected" value={stats?.rejected ?? '—'} />
        <StatCard icon={Store} label="Orders incl. my items" value={stats?.orders ?? '—'} />
      </div>

      {!products ? <div className="grid grid-cols-2 md:grid-cols-4 gap-6">{Array(4).fill(0).map((_, i) => <Skeleton key={i} className="aspect-[3/4] rounded-2xl bg-white/5" />)}</div>
        : products.length === 0 ? (
          <div className="glass rounded-3xl p-16 text-center">
            <Store className="w-12 h-12 mx-auto mb-4 text-neutral-600" />
            <h3 className="font-display text-2xl mb-2">Your rail is empty</h3>
            <p className="text-neutral-500 mb-6 max-w-md mx-auto">Add your first piece. Upload a clean product photo on a plain background so the AI try-on renders it perfectly.</p>
            <Button onClick={() => setEditing({})} className="bg-white text-neutral-900 hover:bg-neutral-200 rounded-full h-12 px-6"><Plus className="w-4 h-4 mr-2" /> Add product</Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6" data-testid="seller-products">
            {products.map(p => (
              <div key={p.id} className="group glass rounded-3xl overflow-hidden">
                <div className="relative aspect-[3/4] bg-neutral-900">
                  <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                  <div className="absolute top-3 left-3"><StatusBadge status={p.status} /></div>
                  <div className="absolute bottom-3 inset-x-3 flex gap-2 opacity-0 group-hover:opacity-100 transition">
                    <Button size="sm" onClick={() => setEditing(p)} className="flex-1 rounded-full bg-white text-neutral-900 hover:bg-neutral-200 h-9 text-xs" data-testid={`edit-${p.id}`}><Pencil className="w-3.5 h-3.5 mr-1" /> Edit</Button>
                    <Button size="sm" variant="outline" onClick={() => remove(p)} className="rounded-full border-white/30 bg-black/40 hover:bg-rose-500/30 h-9 w-9 p-0" aria-label="Delete product"><Trash2 className="w-3.5 h-3.5" /></Button>
                  </div>
                </div>
                <div className="p-4">
                  <div className="text-[10px] tracking-widest text-neutral-500 uppercase">{p.category}</div>
                  <div className="text-sm font-medium truncate">{p.name}</div>
                  <div className="text-sm text-neutral-300">${p.price}</div>
                </div>
              </div>
            ))}
          </div>
        )}

      <ProductDialog product={editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); load() }} />
    </DashboardShell>
  )
}


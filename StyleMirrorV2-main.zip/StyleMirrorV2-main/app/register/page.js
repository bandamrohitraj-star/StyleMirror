'use client'
import React, { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { toast } from 'sonner'
import { Sparkles, Mail, Lock, User, ArrowRight, Loader2, ShoppingBag, Store, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { useAuth, ROLE_HOME } from '@/components/auth-context'
import { SiteHeader } from '@/components/site-header'
import { HERO_IMAGE } from '@/lib/products'

const cn = (...c) => c.filter(Boolean).join(' ')
const inputCls = 'h-12 pl-11 bg-white/5 border-white/10 rounded-2xl text-neutral-100 placeholder:text-neutral-600 focus-visible:ring-amber-200/40'

export default function RegisterPage() {
  const { user, loading, register } = useAuth()
  const router = useRouter()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState('buyer')
  const [busy, setBusy] = useState(false)

  useEffect(() => { if (!loading && user) router.replace(ROLE_HOME[user.role] || '/') }, [user, loading, router])

  const submit = async (e) => {
    e.preventDefault()
    setBusy(true)
    try {
      const u = await register({ name, email, password, wantsSeller: role === 'seller' })
      toast.success(`Welcome to STYLE MIRROR, ${u.name.split(' ')[0]}`, { description: role === 'seller' ? 'Your seller console is ready.' : 'Your wardrobe hub is ready.' })
      router.replace(ROLE_HOME[u.role] || '/')
    } catch (err) { toast.error(err.message) } finally { setBusy(false) }
  }

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100">
      <SiteHeader />
      <div className="min-h-screen grid lg:grid-cols-2">
        <div className="flex items-center justify-center px-6 pt-32 pb-20 lg:pt-20 order-2 lg:order-1">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="w-full max-w-md">
            <div className="glass rounded-3xl p-8 md:p-10">
              <div className="text-xs tracking-widest text-neutral-500 uppercase mb-2">Join the house</div>
              <h1 className="font-display text-4xl md:text-5xl mb-2">Create account</h1>
              <p className="text-neutral-400 text-sm mb-8">Pick how you want to use STYLE MIRROR.</p>
              <div className="grid grid-cols-2 gap-3 mb-6">
                {[['buyer', ShoppingBag, 'I shop', 'Save try-ons, track orders'], ['seller', Store, 'I sell', 'List try-on ready pieces']].map(([k, I, t, d]) => (
                  <button type="button" key={k} onClick={() => setRole(k)} data-testid={`role-${k}`} className={cn('relative text-left rounded-2xl p-4 border transition', role === k ? 'border-amber-200/70 bg-white/10' : 'border-white/10 bg-white/5 hover:border-white/30')}>
                    <I className="w-5 h-5 text-amber-100 mb-2" />
                    <div className="text-sm font-medium">{t}</div>
                    <div className="text-[11px] text-neutral-400">{d}</div>
                    {role === k && <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-amber-200 text-neutral-900 flex items-center justify-center"><Check className="w-3 h-3" /></div>}
                  </button>
                ))}
              </div>
              <form onSubmit={submit} className="space-y-4" data-testid="register-form">
                <div className="relative"><User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" /><Input required value={name} onChange={e => setName(e.target.value)} placeholder="Full name" className={inputCls} data-testid="register-name" /></div>
                <div className="relative"><Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" /><Input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" className={inputCls} data-testid="register-email" /></div>
                <div className="relative"><Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" /><Input type="password" required minLength={6} value={password} onChange={e => setPassword(e.target.value)} placeholder="Password (min 6 characters)" className={inputCls} data-testid="register-password" /></div>
                <Button type="submit" disabled={busy} className="w-full h-12 rounded-full bg-gradient-to-r from-amber-200 to-violet-300 text-neutral-900 hover:opacity-90 font-medium" data-testid="register-submit">
                  {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}{busy ? 'Creating…' : `Create ${role} account`}{!busy && <ArrowRight className="w-4 h-4 ml-2" />}
                </Button>
              </form>
              <p className="text-sm text-neutral-500 text-center mt-6">Already a member? <Link href="/login" className="text-white hover:text-amber-200 underline-offset-4 hover:underline">Sign in</Link></p>
            </div>
          </motion.div>
        </div>
        <div className="relative hidden lg:block overflow-hidden order-1 lg:order-2">
          <img src={HERO_IMAGE} alt="" className="absolute inset-0 w-full h-full object-cover opacity-70" />
          <div className="absolute inset-0 bg-gradient-to-l from-neutral-950/30 via-neutral-950/40 to-neutral-950" />
          <div className="absolute inset-0 gradient-mesh opacity-70" />
          <div className="relative h-full flex flex-col justify-end p-16">
            <Badge className="mb-6 w-fit bg-white/10 border border-white/20 text-white hover:bg-white/10"><Sparkles className="w-3 h-3 mr-1.5" /> Mirror comes with you</Badge>
            <h2 className="font-display text-5xl xl:text-6xl leading-[1] mb-4">Dress <span className="italic gradient-text">sharper</span>, every day.</h2>
            <p className="text-neutral-300 max-w-md">Your AI stylist remembers your fit, your tone and your favourite pieces across every device.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
